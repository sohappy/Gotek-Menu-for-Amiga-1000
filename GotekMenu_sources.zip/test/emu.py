#!/usr/bin/env python3
"""
emu.py : exécute le VRAI DSKA0001_MENU.adf dans un 68000 émulé (Musashi via
machine68k), avec une émulation minimale du matériel Amiga utilisé par le menu
(Paula disque + DMA, CIA-A/B, faisceau vidéo, Copper) branchée sur le
simulateur FlashFloppy (libsim.so). Exec est remplacé par des pièges Python
(AllocMem, DoIO, Supervisor) appelés par le bootblock / le reset.

Usage : SIM_IMG=... SIM_SLOTS=... python3 emu.py ADF "touches" sortie_prefixe
Touches : u d l r f(RETURN) j(feu joystick) R(relire) S(capture) .(attente)
"""
import ctypes, os, struct, sys
import machine68k as m

adf_path, script, outp = sys.argv[1], sys.argv[2], sys.argv[3]
adf = open(adf_path, 'rb').read()
sim = ctypes.CDLL(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'libsim.so'))
sim.sim_init()
U16P = ctypes.POINTER(ctypes.c_uint16)

mach = m.Machine(m.CPUType.M68000, 512)
cpu, mem, traps = mach.cpu, mach.mem, mach.traps
RAM = 512 * 1024

# ---------------- Exec factice ----------------
EXEC = 0x1000
ALLOC_AT = 0x20000
alloc_size = [0]
done = {'reset': False, 'reason': None}

def t_allocmem(op, pc):
    size = cpu.r_reg(m.Register.D0)
    flags = cpu.r_reg(m.Register.D1)
    assert flags & 2, 'MEMF_CHIP attendu'
    alloc_size[0] = size
    assert ALLOC_AT + size < 0x70000, 'trop de mémoire'
    for a in range(ALLOC_AT, ALLOC_AT + size, 4):
        mem.w32(a, 0xDEADBEEF if not (flags & 0x10000) else 0)
    cpu.w_reg(m.Register.D0, ALLOC_AT)

def t_doio(op, pc):
    io = cpu.r_reg(m.Register.A1)
    cmd = mem.r16(io + 28)
    if cmd == 2:
        length, data, off = mem.r32(io + 36), mem.r32(io + 40), mem.r32(io + 44)
        assert off % 512 == 0 and length % 512 == 0
        mem.w_block(data, adf[off:off + length])
    mem.w8(io + 31, 0)
    cpu.w_reg(m.Register.D0, 0)

def t_super(op, pc):
    cpu.w_sr(cpu.r_sr() | 0x2000)

def stub(lvo, func, tail):
    tid = traps.alloc(func)
    mem.w16(EXEC + lvo, 0xA000 | tid)
    mem.w16(EXEC + lvo + 2, tail)

stub(-198, t_allocmem, 0x4E75)   # rts
stub(-456, t_doio, 0x4E75)
stub(-30, t_super, 0x4ED5)       # jmp (a5)
mem.w32(4, EXEC)

def on_reset():
    done['reset'] = True
    done['reason'] = 'RESET'
    mach.abort_execute()
cpu.set_reset_instr_callback(on_reset)

# ---------------- Puces custom ----------------
st = dict(line=0, intreq=0, dskpt=0, dsklen_last=0, adkcon=0, cop1lc=0, dmacon=0,
          prb=0xFF, cra=0, frames=0, handshakes=0, reads=0, writes=0)
keyq = []          # file d'octets SDR à délivrer
sdr = [0xFF]

def vpos():
    return st['line']

def tick():
    st['line'] += 1
    if st['line'] >= 312:
        st['line'] = 0
        st['frames'] += 1

def custom_r16(addr):
    o = addr & 0x1FE
    if o == 0x004:
        return (vpos() >> 8) & 1
    if o == 0x006:
        v = vpos(); tick()
        return (v & 0xFF) << 8
    if o == 0x01E:
        return st['intreq']
    if o == 0x002:
        return st['dmacon']
    if o == 0x00C:
        return 0
    return 0

def custom_r32(addr):
    o = addr & 0x1FE
    if o == 0x004:
        v = vpos(); tick()
        return (((v >> 8) & 1) << 16) | ((v & 0xFF) << 8)
    return (custom_r16(addr) << 16) | custom_r16(addr + 2)

def do_dma(length, write):
    n = length & 0x3FFF
    buf = (ctypes.c_uint16 * n)()
    base = st['dskpt']
    assert base % 2 == 0 and base + 2 * n <= RAM, 'DSKPT hors Chip RAM'
    if write:
        st['writes'] += 1
        raw = mem.r_block(base, 2 * n)
        for i in range(n):
            buf[i] = (raw[2 * i] << 8) | raw[2 * i + 1]
        sim.hw_write_raw(buf, n)
    else:
        st['reads'] += 1
        assert st['adkcon'] & 0x0400, 'WORDSYNC non activé pour la lecture'
        r = sim.hw_read_raw(buf, n)
        if r != 0:
            return  # pas de synchro : pas d'interruption DSKBLK
        mem.w_block(base, b''.join(struct.pack('>H', buf[i]) for i in range(n)))
    st['intreq'] |= 0x0002

def custom_w16(addr, val):
    o = addr & 0x1FE
    if o == 0x020:
        st['dskpt'] = (st['dskpt'] & 0xFFFF) | (val << 16)
    elif o == 0x022:
        st['dskpt'] = (st['dskpt'] & 0xFFFF0000) | val
    elif o == 0x024:
        if (val & 0x8000) and st['dsklen_last'] == val:
            assert st['dmacon'] & 0x0210 == 0x0210, 'DMA disque non autorisé'
            do_dma(val, bool(val & 0x4000))
            val = 0
        st['dsklen_last'] = val
    elif o == 0x09C:
        if val & 0x8000: st['intreq'] |= val & 0x7FFF
        else: st['intreq'] &= ~val
    elif o == 0x09E:
        if val & 0x8000: st['adkcon'] |= val & 0x7FFF
        else: st['adkcon'] &= ~val
    elif o == 0x096:
        if val & 0x8000: st['dmacon'] |= val & 0x7FFF
        else: st['dmacon'] &= ~val
    elif o == 0x080:
        st['cop1lc'] = (st['cop1lc'] & 0xFFFF) | (val << 16)
    elif o == 0x082:
        st['cop1lc'] = (st['cop1lc'] & 0xFFFF0000) | val

def custom_w32(addr, val):
    custom_w16(addr, val >> 16)
    custom_w16(addr + 2, val & 0xFFFF)

# ---------------- CIA ----------------
def cia_r8(addr):
    if addr == 0xBFE001:
        v = 0xFF
        if not (st['prb'] & 0x08):
            v &= ~0x20                     # RDY
        if sim.hw_track0():
            v &= ~0x10                     # TRK0
        if joyfire[0]:
            v &= ~0x80
        return v & 0xFC
    if addr == 0xBFED01:
        if keyq:
            sdr[0] = keyq.pop(0)
            return 0x88
        return 0
    if addr == 0xBFEC01:
        return sdr[0]
    if addr == 0xBFEE01:
        return st['cra']
    if addr == 0xBFD100:
        return st['prb']
    return 0xFF

def cia_w8(addr, val):
    if addr == 0xBFD100:
        old, st['prb'] = st['prb'], val
        if (old & 0x08) and not (val & 0x08):
            if not (val & 0x80): sim.hw_drive_on()
            else: sim.hw_drive_off()
        if not (old & 0x08) and (val & 0x08):
            sim.hw_drive_off()
        if (old & 0x01) and not (val & 0x01):
            sim.hw_step(0 if (val & 0x02) else 1)
    elif addr == 0xBFEE01:
        if (st['cra'] & 0x40) and not (val & 0x40):
            st['handshakes'] += 1
        st['cra'] = val
    elif addr == 0xBFE001:
        raise RuntimeError('écriture CIAA PRA (OVL) interdite')

mem.set_special_range_read_funcs(0xDF0000, 1, r8=lambda a: 0, r16=custom_r16, r32=custom_r32)
mem.set_special_range_write_funcs(0xDF0000, 1, w8=lambda a, v: None, w16=custom_w16, w32=custom_w32)
mem.set_special_range_read_funcs(0xBF0000, 1, r8=cia_r8)
mem.set_special_range_write_funcs(0xBF0000, 1, w8=cia_w8)
def invalid(mode, width, addr):
    raise RuntimeError(f'accès invalide {chr(mode)}{8 << width} {addr:06x} pc={cpu.r_pc():06x}')
mem.set_invalid_func(invalid)

# ---------------- Capture d'écran ----------------
snap_n = [0]
def snapshot():
    cop = st['cop1lc']
    words, bpl = [], 0
    a = cop
    while True:
        w1, w2 = mem.r16(a), mem.r16(a + 2)
        words += [w1, w2]
        a += 4
        if w1 == 0xFFFF and w2 == 0xFFFE: break
        if w1 == 0x0E0: bpl = (bpl & 0xFFFF) | (w2 << 16)
        if w1 == 0x0E2: bpl = (bpl & 0xFFFF0000) | w2
    data = mem.r_block(bpl, 16000) + b''.join(struct.pack('>H', w) for w in words)
    fn = f'{outp}{snap_n[0]:02d}.bin'
    open(fn, 'wb').write(data)
    snap_n[0] += 1
    print('capture', fn)

# ---------------- Démarrage : bootblock ----------------
BB = 0x3000; IO = 0x2000
mem.w_block(BB, adf[:1024])
assert adf[:4] == b'DOS\0'
cpu.w_reg(m.Register.A1, IO)
cpu.w_reg(m.Register.A6, EXEC)
cpu.w_sp(0x7F000)
mem.w32(0x7F000, 0x7FF00)          # adresse de retour du bootblock
cpu.w_sr(0x0000)                   # mode utilisateur comme sous la strap
cpu.w_usp(0x7F000)
cpu.w_pc(BB + 12)

KEYS = {'u': 0x4C, 'd': 0x4D, 'l': 0x4F, 'r': 0x4E, 'f': 0x44, 'R': 0x13}
def enc(code):  # octet SDR tel que lu par le CPU
    c = ((code << 1) | (code >> 7)) & 0xFF
    return (~c) & 0xFF
joyfire = [False]

def run_frames(n):
    target = st['frames'] + n
    while st['frames'] < target and not done['reset']:
        mach.execute(20000)

run_frames(40)
for k in script:
    if done['reset']: break
    if k == 'S':
        snapshot()
    elif k == '.':
        run_frames(30)
    elif k == 'j':
        joyfire[0] = True; run_frames(3); joyfire[0] = False
    elif k in KEYS:
        keyq.append(enc(KEYS[k])); run_frames(3)
        keyq.append(enc(KEYS[k] | 0x80)); run_frames(3)
    run_frames(2)
if not done['reset']:
    run_frames(400)
snapshot()
print(f"fin : {done['reason'] or 'pas de reset'} ; image montée DSKA{sim.sim_mounted_slot():04d} ; "
      f"DMA lectures {st['reads']} écritures {st['writes']} ; poignées de main clavier {st['handshakes']} ; "
      f"PC {cpu.r_pc():06x} ; mémoire allouée {alloc_size[0]}")
