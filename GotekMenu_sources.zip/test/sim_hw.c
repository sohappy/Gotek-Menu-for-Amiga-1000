/*
 * sim_hw.c : simulation PC du Gotek FlashFloppy en mode Direct Access.
 * Génération de la piste DA et analyse des écritures reprises de
 * FlashFloppy src/image/da.c (mfm_read_track / mfm_write_track /
 * process_wdata), plus perturbations (latence, erreurs de bits).
 *
 * Variables d'environnement :
 *   SIM_IMG    image de la clé USB (FAT)
 *   SIM_SLOTS  liste des emplacements valides "0,1,2,..."
 *   SIM_KEYS   script d'entrées : u d l r f h e R S(capture) .(attente)
 *   SIM_OUT    préfixe des captures
 *   SIM_NOISE  1 = erreurs aléatoires et latence
 *   SIM_NODA   1 = Gotek sans Direct Access (max-cyl < 255)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../src/hw.h"

#define SEC_SZ 512
#define NR_SEC 8
#define MFM_GAP_SYNC 12
#define MFM_GAP_1    50
#define MFM_GAP_2    22
#define MFM_GAP_3    84
#define MFM_GAP_4   192
#define MFM_GAP_4A   80

static FILE *img;
static int cyl = 7, selected, noise, noda;
static int slot_ok[1000];
static int cur_slot = 1, mounted_slot = 1;
static int da_dirty;

/* état DA (struct da_status_sector) */
static uint32_t lba_base;
static uint8_t cmd_cnt, read_cnt, write_cnt, last_status, nr_sec = 8;
static uint16_t current_index;
/* latence : la commande écrite n'est visible qu'après N mots lus */
static int pending, pending_delay;
static uint32_t p_lba; static uint8_t p_cnt, p_status, p_nr; static uint16_t p_idx;

static const uint8_t *cur_bpl;
static const uint16_t *cur_cop;
static const char *keys;
static int frame, snap, nwrites, nreads;
static const char *outp;

static uint16_t crc16(const uint8_t *p, unsigned n, uint16_t crc)
{
    unsigned i;
    while (n--) {
        crc ^= (uint16_t)(*p++ << 8);
        for (i = 0; i < 8; i++)
            crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021) : (uint16_t)(crc << 1);
    }
    return crc;
}
static uint16_t bintomfm(uint8_t b)
{
    uint16_t w = 0; int i;
    for (i = 7; i >= 0; i--) w = (uint16_t)((w << 2) | ((b >> i) & 1));
    return w;
}
static uint8_t mfmtobin(uint16_t w)
{
    uint8_t b = 0; int i;
    for (i = 7; i >= 0; i--) b = (uint8_t)((b << 1) | ((w >> (2 * i)) & 1));
    return b;
}

static void apply_pending(void)
{
    if (!pending) return;
    pending = 0;
    lba_base = p_lba; cmd_cnt = p_cnt; last_status = p_status; nr_sec = p_nr;
    current_index = p_idx;
}

static void da_reset(void)
{
    lba_base = 0; cmd_cnt = read_cnt = write_cnt = last_status = 0;
    nr_sec = 8; current_index = (uint16_t)mounted_slot; pending = 0;
}

static void read_lba(uint32_t lba, uint8_t *buf)
{
    memset(buf, 0, SEC_SZ);
    if (fseek(img, (long)lba * 512, SEEK_SET) == 0)
        if (fread(buf, 1, SEC_SZ, img) != SEC_SZ) memset(buf, 0, SEC_SZ);
}

/* --- génération de la piste (port de mfm_read_track) --- */
static uint16_t trk[16384 * 2];
static unsigned tn;
static uint16_t pr;
static void emit_raw(uint16_t r) { trk[tn++] = (uint16_t)(r & ~(pr << 15)); pr = r; }
static void emit_byte(uint8_t b) { emit_raw(bintomfm(b)); }

static void gen_sector_content(int sec, uint8_t *buf)
{
    if (sec == 0) {
        memset(buf, 0, SEC_SZ);
        memcpy(buf, "HxCFEDA", 8);
        snprintf((char *)buf + 8, 12, "FF-v3.44");
        buf[20] = (uint8_t)lba_base; buf[21] = (uint8_t)(lba_base >> 8);
        buf[22] = (uint8_t)(lba_base >> 16); buf[23] = (uint8_t)(lba_base >> 24);
        buf[24] = cmd_cnt; buf[25] = read_cnt++; buf[26] = write_cnt;
        buf[27] = last_status; buf[33] = nr_sec;
        buf[34] = (uint8_t)current_index; buf[35] = (uint8_t)(current_index >> 8);
    } else {
        read_lba(lba_base + (uint32_t)sec - 1, buf);
    }
}

/* Une révolution, en commençant au début ; contenu calculé à la volée. */
static void gen_rev(void)
{
    uint8_t buf[SEC_SZ];
    int s; unsigned i;
    for (i = 0; i < MFM_GAP_4A; i++) emit_byte(0x4e);
    for (i = 0; i < MFM_GAP_SYNC; i++) emit_byte(0x00);
    for (i = 0; i < 3; i++) emit_raw(0x5224);
    emit_byte(0xfc);
    for (i = 0; i < MFM_GAP_1; i++) emit_byte(0x4e);
    for (s = 0; s <= nr_sec; s++) {
        uint8_t idam[8] = { 0xa1, 0xa1, 0xa1, 0xfe, 255, 0, (uint8_t)s, 2 };
        uint8_t dam[4] = { 0xa1, 0xa1, 0xa1, 0xfb };
        uint16_t crc;
        if (pending && pending_delay-- <= 0) apply_pending();
        for (i = 0; i < MFM_GAP_SYNC; i++) emit_byte(0x00);
        for (i = 0; i < 3; i++) emit_raw(0x4489);
        for (i = 3; i < 8; i++) emit_byte(idam[i]);
        crc = crc16(idam, 8, 0xffff);
        emit_byte((uint8_t)(crc >> 8)); emit_byte((uint8_t)crc);
        for (i = 0; i < MFM_GAP_2; i++) emit_byte(0x4e);
        gen_sector_content(s, buf);
        for (i = 0; i < MFM_GAP_SYNC; i++) emit_byte(0x00);
        for (i = 0; i < 3; i++) emit_raw(0x4489);
        emit_byte(dam[3]);
        crc = crc16(dam, 4, 0xffff);
        crc = crc16(buf, SEC_SZ, crc);
        for (i = 0; i < SEC_SZ; i++) emit_byte(buf[i]);
        emit_byte((uint8_t)(crc >> 8)); emit_byte((uint8_t)crc);
        for (i = 0; i < MFM_GAP_3; i++) emit_byte(0x4e);
    }
    for (i = 0; i < MFM_GAP_4; i++) emit_byte(0x4e);
}

int hw_read_raw(uint16_t *buf, unsigned n)
{
    unsigned start, i, k, revlen;
    nreads++;
    if (!selected || cyl != 255 || noda) {
        memset(buf, 0xAA, n * 2);
        return -1;                  /* pas de synchro : délai dépassé */
    }
    if (n > 16383) { fprintf(stderr, "DSKLEN trop grand\n"); exit(2); }
    /* position de départ aléatoire dans la rotation */
    tn = 0; pr = 0;
    gen_rev(); revlen = tn;
    if (revlen < 6200 || revlen > 6300) { fprintf(stderr, "revlen %u\n", revlen); exit(2); }
    start = (unsigned)rand() % revlen;
    while (tn < start + n + revlen) gen_rev();
    /* WORDSYNC : le DMA démarre après le premier 0x4489 */
    for (i = start; trk[i] != 0x4489; i++) ;
    i++;
    for (k = 0; k < n; k++) buf[k] = trk[i + k];
    if (noise && (rand() % 3) == 0) {     /* quelques bits corrompus */
        int m = 1 + rand() % 3;
        while (m--) buf[rand() % n] ^= (uint16_t)(1u << (rand() % 16));
    }
    return 0;
}

/* --- analyse des écritures (port de mfm_write_track/process_wdata) --- */
static void process(unsigned sect, const uint8_t *wr, uint16_t crc)
{
    unsigned i;
    crc = crc16(wr, SEC_SZ + 2, crc);
    if (crc != 0 || sect > nr_sec) {
        printf("[sim] D-A secteur invalide CRC %04x ID %u\n", crc, sect);
        return;
    }
    if (sect != 0) { printf("[sim] écriture secteur %u ignorée\n", sect); return; }
    if (memcmp(wr, "HxCFEDA", 8)) { printf("[sim] mauvaise signature\n"); return; }
    p_lba = lba_base; p_cnt = (uint8_t)(cmd_cnt + 1); p_status = 1; p_nr = nr_sec;
    p_idx = current_index;
    switch (wr[8]) {
    case 0: p_status = 0; break;
    case 1:
        p_lba = 0;
        for (i = 0; i < 4; i++) p_lba = (p_lba << 8) | wr[9 + 3 - i];
        p_nr = wr[9 + 5] ? wr[9 + 5] : 8;
        p_status = 0;
        break;
    case 4: {
        uint16_t idx = (uint16_t)(wr[9] | (wr[10] << 8));
        if (idx < 1000 && slot_ok[idx]) {
            cur_slot = idx; p_idx = idx; p_status = 0; da_dirty = 1;
            printf("[sim] D-A Img %u -> %u (OK)\n", current_index, idx);
        } else printf("[sim] D-A Img %u (Bad)\n", idx);
        break;
    }
    default: printf("[sim] commande inconnue %02x\n", wr[8]);
    }
    pending = 1;
    pending_delay = noise ? rand() % 12 : 0;
    if (!noise) apply_pending();
}

int hw_write_raw(const uint16_t *b, unsigned n)
{
    unsigned c = 0, k; int prev = 0;
    uint8_t wr[SEC_SZ + 2];
    nwrites++;
    if (!selected || cyl != 255) return 0;
    /* vérifie les règles MFM (bits d'horloge) */
    for (k = 0; k < n; k++) {
        uint16_t w = b[k]; int i;
        if (w == 0x4489) { prev = 1; continue; }
        for (i = 7; i >= 0; i--) {
            int cbit = (w >> (2 * i + 1)) & 1, d = (w >> (2 * i)) & 1;
            if (cbit != (!prev && !d)) { fprintf(stderr, "MFM invalide mot %u\n", k); exit(3); }
            prev = d;
        }
    }
    if (noise && rand() % 5 == 0) { printf("[sim] écriture perdue\n"); return 0; }
    while ((int)(n - c) > 128) {
        unsigned sc = c, sect; uint8_t x; uint16_t crc;
        if (b[c++] != 0x4489) continue;
        if ((x = mfmtobin(b[c])) == 0xa1) continue;
        c++;
        if (x == 0x01) {
            uint8_t h[5] = { 0xa1, 0xa1, 0xa1, 0x01, 0 };
            sect = h[4] = mfmtobin(b[c++]);
            crc = crc16(h, 5, 0xffff);
        } else continue;
        if ((int)(n - c) < SEC_SZ + 2) { c = sc; break; }
        for (k = 0; k < SEC_SZ + 2; k++) wr[k] = mfmtobin(b[c + k]);
        c += SEC_SZ + 2;
        process(sect, wr, crc);
    }
    return 0;
}

/* --- mécanique --- */
void hw_drive_on(void) { selected = 1; }
void hw_drive_off(void) { selected = 0; }
int hw_track0(void) { return cyl == 0; }
void hw_step(int inward)
{
    int prev = cyl;
    if (!selected) return;
    if (inward) { if (cyl < 255) cyl++; } else if (cyl > 0) cyl--;
    if (cyl == 255 && prev != 255) da_reset();   /* FF : memset(&im->da) */
    if (cyl < 254 && prev >= 254) {
        if (da_dirty) { mounted_slot = cur_slot; da_dirty = 0; }
        printf("[sim] sortie Direct Access : image montée = DSKA%04u\n", mounted_slot);
    }
}
void hw_settle(void) {}
void hw_delay_ms(unsigned ms) { (void)ms; }

/* --- affichage / entrées --- */
void hw_takeover(void) {}
void hw_set_display(const uint8_t *bpl, const uint16_t *cop) { cur_bpl = bpl; cur_cop = cop; }
void hw_wait_frame(void) { frame++; }

static void snapshot(void)
{
    char fn[256]; FILE *f; int n = 0;
    snprintf(fn, sizeof fn, "%s%02d.bin", outp, snap++);
    f = fopen(fn, "wb");
    fwrite(cur_bpl, 1, 16000, f);
    while (!(cur_cop[n] == 0xFFFF && cur_cop[n + 1] == 0xFFFE)) n += 2;
    n += 2;
    { int i; for (i = 0; i < n; i++) { uint8_t be[2] = { (uint8_t)(cur_cop[i] >> 8), (uint8_t)cur_cop[i] }; fwrite(be, 1, 2, f); } }
    fclose(f);
    printf("[sim] capture %s\n", fn);
}

int hw_input(void)
{
    char k;
    if (!keys || !*keys) {
        snapshot();
        printf("[sim] fin du script (lectures %d, écritures %d)\n", nreads, nwrites);
        exit(0);
    }
    k = *keys++;
    switch (k) {
    case 'u': return KEY_UP;
    case 'd': return KEY_DOWN;
    case 'l': return KEY_LEFT;
    case 'r': return KEY_RIGHT;
    case 'f': return KEY_FIRE;
    case 'h': return KEY_HOME;
    case 'e': return KEY_END;
    case 'R': return KEY_RESCAN;
    case 'S': snapshot(); return KEY_NONE;
    case 'N': noda = 0; return KEY_NONE;   /* "répare" le Gotek */
    default: return KEY_NONE;
    }
}

void hw_reboot(void)
{
    snapshot();
    printf("[sim] REBOOT -> l'Amiga démarre DSKA%04u (lectures %d, écritures %d)\n",
           mounted_slot, nreads, nwrites);
    exit(0);
}

void sim_init(void);
void sim_init(void)
{
    const char *s = getenv("SIM_SLOTS");
    img = fopen(getenv("SIM_IMG"), "rb");
    if (!img) { perror("SIM_IMG"); exit(1); }
    while (s && *s) { slot_ok[atoi(s)] = 1; s = strchr(s, ','); if (s) s++; }
    keys = getenv("SIM_KEYS");
    outp = getenv("SIM_OUT") ? getenv("SIM_OUT") : "snap";
    noise = getenv("SIM_NOISE") && atoi(getenv("SIM_NOISE"));
    noda = getenv("SIM_NODA") && atoi(getenv("SIM_NODA"));
    srand(getenv("SIM_SEED") ? (unsigned)atoi(getenv("SIM_SEED")) : 1);
}

/* Accesseur pour le banc d'émulation 68000 (emu.py) */
int sim_mounted_slot(void);
int sim_mounted_slot(void) { return mounted_slot; }
