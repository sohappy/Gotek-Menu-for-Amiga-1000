#!/usr/bin/env python3
"""Rend une capture du simulateur (plan de bits + liste Copper) en PNG."""
import sys, struct
from PIL import Image
def c12(v): return (((v>>8)&15)*17, ((v>>4)&15)*17, (v&15)*17)
def render(fn, out):
    d = open(fn,'rb').read()
    bpl, cop = d[:16000], d[16000:]
    words = struct.unpack('>%dH' % (len(cop)//2), cop)
    events = []  # (line, reg, val)
    line = 0; c = {0x180:0, 0x182:0xFFF}
    for i in range(0, len(words), 2):
        a, b = words[i], words[i+1]
        if a == 0xFFFF and b == 0xFFFE: break
        if a & 1: line = a >> 8
        else: events.append((line, a, b))
    W, H, TOP, MARGIN = 640, 200, 0x2C, 16
    img = Image.new('RGB', (W + 2*MARGIN, (H + 2*MARGIN//2)*2))
    px = img.load()
    for y in range(-MARGIN//2, H + MARGIN//2):
        ln = TOP + y
        for (l, r, v) in events:
            if l <= ln: c[r] = v
        c0, c1 = c12(c[0x180]), c12(c[0x182])
        c = {0x180:0, 0x182:0xFFF}  # recalcul complet par ligne
        for (l, r, v) in events:
            if l <= ln: c[r] = v
        c0, c1 = c12(c[0x180]), c12(c[0x182])
        for x in range(W + 2*MARGIN):
            xx = x - MARGIN
            on = 0 <= y < H and 0 <= xx < W and (bpl[y*80 + xx//8] >> (7 - xx % 8)) & 1
            col = c1 if on else c0
            yy = (y + MARGIN//2)*2
            px[x, yy] = col; px[x, yy+1] = col
    img.save(out)
for a in sys.argv[1:]:
    render(a, a.replace('.bin', '.png'))
