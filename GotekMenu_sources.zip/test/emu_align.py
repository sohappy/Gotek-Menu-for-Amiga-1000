# lance emu.py en vérifiant l'alignement des accès 16/32 bits (erreur d'adresse sur 68000)
import runpy, sys, machine68k as m
orig = m.Machine.__init__
bad = []
class Hook:
    pass
import builtins
_real = m.Machine
def patched(*a, **k):
    mach = _real(*a, **k)
    def tr(mode, width, addr, val):
        if width > 0 and (addr & 1):
            bad.append((str(mode), 8 << width, addr, mach.cpu.r_pc()))
            if len(bad) < 10:
                print('ACCES IMPAIR', str(mode), 8 << width, hex(addr), 'pc', hex(mach.cpu.r_pc()))
    mach.mem.set_trace_func(tr)
    mach.mem.set_trace_mode(1)
    return mach
m.Machine = patched
sys.argv = ['emu.py'] + sys.argv[1:]
try:
    runpy.run_path('emu.py', run_name='__main__')
finally:
    print('accès impairs :', len(bad))
