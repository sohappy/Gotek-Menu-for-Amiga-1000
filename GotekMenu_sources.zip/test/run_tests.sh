#!/bin/bash
# Batterie de scénarios du simulateur. Échoue au premier écart.
set -u
pass=0; fail=0
t() { # nom image clés attendu [env...]
  local name=$1 img=$2 keys=$3 expect=$4; shift 4
  out=$(env SIM_IMG=$img SIM_SLOTS=$(cat $img.slots) SIM_KEYS="$keys" SIM_OUT=out/${name}_ "$@" ./sim 2>&1 | iconv -f latin1 -t utf-8)
  if echo "$out" | grep -q -- "$expect"; then pass=$((pass+1)); echo "OK   $name"
  else fail=$((fail+1)); echo "FAIL $name (attendu: $expect)"; echo "$out" | tail -8; fi
}
t fat32_launch   usb_fat32.img "ddddSf"   "REBOOT -> l'Amiga démarre DSKA0006"
t fat32_end      usb_fat32.img "eSf"      "démarre DSKA0060"
t fat32_page     usb_fat32.img "rSrSf"    "démarre DSKA0060"
t fat32_pageback usb_fat32.img "rrlSf"    "démarre DSKA0020"
t fat32_wrap     usb_fat32.img "uuuf"     "démarre DSKA0002"
t fat16_launch   usb_fat16.img "dSf"      "démarre DSKA0003"
t fat12_launch   usb_fat12.img "eSf"      "démarre DSKA0060"
t fat12_list     usb_fat12.img "S"        "fin du script"
t noda_retry     usb_fat32.img "..SN.fdf" "démarre DSKA0003" SIM_NODA=1
t rescan         usb_fat32.img "ddRdf"    "démarre DSKA0003"
for seed in $(seq 1 25); do
  k=$(( (seed * 7) % 38 )); slots=(2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 50 52 60)
  keys=""; for i in $(seq 1 $k); do keys="${keys}d"; done
  t noise_$seed usb_fat32.img "${keys}f" "démarre $(printf 'DSKA%04d' ${slots[$k]})" SIM_NOISE=1 SIM_SEED=$seed
done
echo "== $pass réussis, $fail échoués"
