#!/usr/bin/env python3
"""Crée des images de clés USB de test (FAT32 avec MBR, FAT16 superfloppy, FAT12)."""
import os, subprocess, tempfile
os.environ['LC_ALL'] = 'C.UTF-8'
D = os.path.dirname(os.path.abspath(__file__))
ADF = 901120
games = ["Workbench 1.3", "Lemmings", "Shadow of the Beast (Disk 1)", "Shadow of the Beast (Disk 2)",
         "Defender of the Crown", "Marble Madness", "Arkanoid", "Barbarian", "Dungeon Master",
         "Speedball", "Xenon 2 Megablast", "Turrican", "Populous", "Le Manoir de Mortevielle",
         "Éric Chahut - Dessins animés", "Another World", "Kick Off 2", "Pinball Dreams",
         "Sword of Sodan", "Interceptor", "Deluxe Paint", "Silkworm", "R-Type", "Menace",
         "Blood Money", "Sim City", "Captain Blood", "North & South", "Rick Dangerous",
         "Elite", "Battle Squadron", "Great Giana Sisters", "IK+", "Super Cars",
         "Un nom de fichier vraiment très long pour vérifier la troncature à l'écran du menu Gotek"]
files = [("DSKA0000_KICKSTART_A1000.adf", ADF), ("DSKA0001_MENU.adf", ADF)]
for i, g in enumerate(games):
    files.append((f"DSKA{i+2:04d}_{g.replace(' ', '_')}.adf", ADF))
files += [("DSKA0050.adf", ADF),                   # sans nom
          ("DSKA0051_Mauvaise taille.adf", 12345),  # taille invalide -> exclu
          ("DSKA0052_Image HxC.hfe", 2080256),
          ("DSKA0007_Doublon.adf", ADF),            # doublon de 0007 -> ignoré
          ("dska0060_minuscules.ADF", ADF),
          ("FF.CFG", 100), ("IMAGE_A.CFG", 20), ("._DSKA0003_Lemmings.adf", 4096),
          ("DSKA0070_Vide.adf", 0)]
dirs = ["DSKA0099_Dossier"]
deleted = "DSKA0080_Efface.adf"

def valid_slots(fl):
    seen = {}
    for n, sz in fl:
        u = n.upper()
        if not u.startswith("DSKA") or not u[4:8].isdigit() or sz == 0: continue
        ext = n.rsplit('.', 1)[-1].lower()
        if ext == 'adf' and sz % 11264: continue
        if ext not in ('adf', 'hfe'): continue
        seen.setdefault(int(u[4:8]), n)
    return seen

def build(name, size_mb, fat, mbr, spc=None):
    path = os.path.join(D, name)
    with open(path, 'wb') as f: f.truncate(size_mb << 20)
    off = 0
    if mbr:
        off = 2048 * 512
        subprocess.run(['sfdisk', '-q', path], input=f'2048,,{"c" if fat==32 else "6"}\n', text=True, check=True)
    args = ['mkfs.fat', '-F', str(fat), '-n', 'GOTEK']
    if mbr: args += ['--offset', '2048']
    if spc: args += ['-s', str(spc)]
    if fat == 32: pass
    else: args += ['-r', '512'] if fat == 16 else []
    subprocess.run(args + [path], check=True, capture_output=True)
    target = f'{path}@@{off}'
    tmp = tempfile.mkdtemp()
    def put(n, sz):
        p = os.path.join(tmp, 'x'); open(p, 'wb').truncate(sz)
        subprocess.run(['mcopy', '-i', target, p, '::' + n], check=True)
    put(deleted, ADF)
    fl = files if fat != 12 else files[:6] + files[-9:-4]
    for n, sz in fl: put(n, sz)
    for d in dirs: subprocess.run(['mmd', '-i', target, '::' + d], check=True)
    subprocess.run(['mdel', '-i', target, '::' + deleted], check=True)
    v = valid_slots(fl)
    print(name, 'slots', sorted(v))
    open(path + '.slots', 'w').write(','.join(str(s) for s in sorted(v)))

build('usb_fat32.img', 64, 32, True, spc=1)     # 512 o/cluster : racine sur plusieurs clusters
build('usb_fat16.img', 40, 16, False)
build('usb_fat12.img', 15, 12, False)
