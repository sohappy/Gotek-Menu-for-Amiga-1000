void sim_init(void);
int menu_main(void);
int main(void) { sim_init(); return menu_main(); }
