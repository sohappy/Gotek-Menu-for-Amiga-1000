/*
 * main.c : GotekMenu — menu de lancement pour Amiga 1000 + Gotek FlashFloppy.
 *
 * Fonctionnement :
 *  1. lit le répertoire racine de la clé USB via le mode Direct Access ;
 *  2. affiche les images DSKAnnnn*.adf (mode indexé) ;
 *  3. au choix, envoie CMD_SELECT_IMAGE au Gotek, ramène la tête au
 *     cylindre 0 (le Gotek monte la nouvelle image) puis redémarre l'Amiga
 *     à chaud : le Kickstart reste en mémoire (WCS) et le disque démarre.
 */
#include "common.h"
#include "hw.h"
#include "da.h"
#include "fat.h"
#include "ui.h"

#define MAX_ENTRIES 400
#define NAME_MAX    66

struct entry {
    uint16_t slot;
    char     name[NAME_MAX + 1] __attribute__((aligned(4)));
};

static struct entry entries[MAX_ENTRIES];
static uint16_t     order[MAX_ENTRIES];
static unsigned     n_entries;
static uint8_t      slot_seen[1000 / 8 + 1];
static uint16_t     own_slot;
static struct da_status dast;
static uint8_t      bitplane[UI_BPL_BYTES];

/* Couleurs */
#define C_BG      0x113
#define C_TEXT    0xBBC
#define C_HEAD_BG 0x25A
#define C_HEAD_FG 0xFFF
#define C_BAR_BG  0xFA2
#define C_BAR_FG  0x000
#define C_FOOT_BG 0x335
#define C_FOOT_FG 0xDDF
#define C_DIM     0x68A
#define C_LINE    0x46A
#define C_ERR     0xF66

/* Mise en page */
#define ROW_TITLE   0
#define ROW_SUB     1
#define ROW_SEP1    2
#define ROW_LIST0   3
#define LIST_ROWS   19
#define ROW_SEP2    22
#define ROW_FOOT    23
#define ROW_STATUS  24

/* ------------------------------------------------------------------ */
/* petites aides texte                                                   */

static char *put_str(char *d, const char *s)
{
    while (*s)
        *d++ = *s++;
    *d = 0;
    return d;
}

static char *put_uint(char *d, unsigned v, int width)
{
    char tmp[6] __attribute__((aligned(4)));
    int n = 0;
    do {
        unsigned q = 0, r = v;
        while (r >= 10) { /* division par 10 sans libgcc */
            r -= 10;
            q++;
        }
        tmp[n++] = (char)('0' + r);
        v = q;
    } while (v && n < 5);
    while (n < width)
        tmp[n++] = '0';
    while (n)
        *d++ = tmp[--n];
    *d = 0;
    return d;
}

static unsigned char lower(unsigned char c)
{
    return (c >= 'A' && c <= 'Z') ? (unsigned char)(c + 32) : c;
}

/* ------------------------------------------------------------------ */
/* Catalogue                                                             */

static int ext_is_image(const char *ext, uint32_t size)
{
    static const char *const exts[] = {
        "adf", "hfe", "img", "ima", "dsk", "st", "scp", "d81", "xdf", 0
    };
    char e[5] __attribute__((aligned(4)));
    int i, j;
    for (i = 0; i < 4 && ext[i]; i++)
        e[i] = (char)lower((unsigned char)ext[i]);
    if (ext[i])
        return 0;
    e[i] = 0;
    for (j = 0; exts[j]; j++) {
        const char *x = exts[j];
        for (i = 0; x[i] && x[i] == e[i]; i++)
            ;
        if (!x[i] && !e[i]) {
            if (j == 0) { /* .adf : multiple de 11*2*512 (comme FlashFloppy) */
                uint32_t t = size;
                while (t >= 11264u * 16)
                    t -= 11264u * 16;
                while (t >= 11264u)
                    t -= 11264u;
                return t == 0;
            }
            return 1;
        }
    }
    return 0;
}

static void add_entry(const char *fname, uint32_t size, uint8_t attr)
{
    const char *p = INDEX_PREFIX, *ext = 0, *q;
    struct entry *e;
    unsigned idx = 0, i, n = 0;

    if ((attr & FAT_ATTR_DIR) || size == 0 || n_entries >= MAX_ENTRIES)
        return;
    for (i = 0; p[i]; i++)
        if (lower((unsigned char)fname[i]) != lower((unsigned char)p[i]))
            return;
    for (; i < 8; i++) {
        if (fname[i] < '0' || fname[i] > '9')
            return;
        idx = idx * 10 + (unsigned)(fname[i] - '0');
    }
    if (idx > 999)
        return;
    for (q = fname; *q; q++)
        if (*q == '.')
            ext = q;
    if (!ext || !ext_is_image(ext + 1, size))
        return;
    if (slot_seen[idx >> 3] & (1 << (idx & 7)))
        return; /* FlashFloppy prend la première correspondance */
    slot_seen[idx >> 3] |= (uint8_t)(1 << (idx & 7));
    if (idx == own_slot || idx == 0)
        return; /* le menu lui-même et le Kickstart (DSKA0000) */

    e = &entries[n_entries++];
    e->slot = (uint16_t)idx;
    /* Nom affiché : on retire "DSKAnnnn", les séparateurs et l'extension */
    q = fname + 8;
    while (*q == '_' || *q == '-' || *q == ' ' || *q == '.')
        q++;
    if (q > ext)
        q = ext;
    while (q < ext && n < NAME_MAX) {
        char c = *q++;
        e->name[n++] = (c == '_') ? ' ' : c;
    }
    while (n && e->name[n - 1] == ' ')
        n--;
    e->name[n] = 0;
    if (!n)
        put_str(e->name, "(sans nom)");
}

static void sort_entries(void)
{
    unsigned i, j;
    for (i = 0; i < n_entries; i++)
        order[i] = (uint16_t)i;
    for (i = 1; i < n_entries; i++) {
        uint16_t v = order[i];
        for (j = i; j > 0 && entries[order[j - 1]].slot > entries[v].slot; j--)
            order[j] = order[j - 1];
        order[j] = v;
    }
}

/* ------------------------------------------------------------------ */
/* Écran                                                                 */

static void show(void)
{
    hw_set_display(bitplane, ui_build_copper());
}

static void draw_frame(void)
{
    int r;
    for (r = 0; r < UI_ROWS; r++)
        ui_row_colors(r, C_BG, C_TEXT);
    ui_clear_rows(0, UI_ROWS - 1);
    ui_row_colors(ROW_TITLE, C_HEAD_BG, C_HEAD_FG);
    ui_row_colors(ROW_SUB, C_HEAD_BG, 0xACF);
    ui_print(2, ROW_TITLE, "\x82  GOTEK MENU  -  Amiga 1000");
    ui_print(UI_COLS - 31, ROW_TITLE, "v1.2  FlashFloppy mode indexé");
    ui_row_colors(ROW_SEP1, C_BG, C_LINE);
    ui_hline(ROW_SEP1, 3);
    ui_row_colors(ROW_SEP2, C_BG, C_LINE);
    ui_hline(ROW_SEP2, 4);
    ui_row_colors(ROW_FOOT, C_FOOT_BG, C_FOOT_FG);
    ui_row_colors(ROW_STATUS, C_BG, C_DIM);
}

static void footer(const char *s)
{
    ui_clear_row(ROW_FOOT);
    ui_print(2, ROW_FOOT, s);
}

static void status_line(const char *s)
{
    ui_clear_row(ROW_STATUS);
    ui_print(2, ROW_STATUS, s);
}

static void subtitle(const char *s)
{
    ui_clear_row(ROW_SUB);
    ui_print(2, ROW_SUB, s);
}

/* Message centré dans la zone de liste (2 lignes). */
static void message(const char *l1, const char *l2, uint16_t color)
{
    int r;
    for (r = ROW_LIST0; r < ROW_LIST0 + LIST_ROWS; r++)
        ui_row_colors(r, C_BG, C_TEXT);
    ui_clear_rows(ROW_LIST0, ROW_LIST0 + LIST_ROWS - 1);
    ui_row_colors(11, C_BG, color);
    ui_center(11, l1);
    if (l2)
        ui_center(13, l2);
    show();
}

static void wait_fire(void)
{
    int k;
    do {
        hw_wait_frame();
        k = hw_input();
    } while (k != KEY_FIRE && k != KEY_RESCAN);
}

/* ------------------------------------------------------------------ */
/* Liste                                                                 */

static unsigned sel, top;

static void draw_list(void)
{
    unsigned i;
    char buf[12] __attribute__((aligned(4)));
    for (i = 0; i < LIST_ROWS; i++) {
        unsigned k = top + i;
        int row = ROW_LIST0 + (int)i;
        ui_clear_row(row);
        ui_row_colors(row, C_BG, C_TEXT);
        if (k < n_entries) {
            const struct entry *e = &entries[order[k]];
            put_uint(buf, e->slot, 3);
            ui_print(4, row, buf);
            ui_print_n(10, row, e->name, NAME_MAX);
        }
    }
    if (top > 0)
        ui_putc(UI_COLS - 2, ROW_LIST0, 0x80);
    if (top + LIST_ROWS < n_entries)
        ui_putc(UI_COLS - 2, ROW_LIST0 + LIST_ROWS - 1, 0x81);
}

static void update_selection(int redraw)
{
    char buf[80], *p;
    int row;
    if (sel < top) {
        top = sel;
        redraw = 1;
    } else if (sel >= top + LIST_ROWS) {
        top = sel - LIST_ROWS + 1;
        redraw = 1;
    }
    if (redraw)
        draw_list();
    else {
        int r;
        for (r = ROW_LIST0; r < ROW_LIST0 + LIST_ROWS; r++) {
            ui_row_colors(r, C_BG, C_TEXT);
            ui_putc(2, r, ' ');
        }
    }
    row = ROW_LIST0 + (int)(sel - top);
    ui_row_colors(row, C_BAR_BG, C_BAR_FG);
    ui_putc(2, row, 0x83);

    p = put_str(buf, "Disquette ");
    p = put_uint(p, sel + 1, 1);
    p = put_str(p, " / ");
    p = put_uint(p, n_entries, 1);
    p = put_str(p, "     emplacement DSKA");
    p = put_uint(p, entries[order[sel]].slot, 4);
    p = put_str(p, "     menu = DSKA");
    put_uint(p, own_slot, 4);
    status_line(buf);
    show();
}

/* ------------------------------------------------------------------ */
/* Lecture de la clé                                                     */

static char *put_hex(char *d, unsigned v, int digits)
{
    while (digits--) {
        unsigned n = (v >> (digits * 4)) & 15;
        *d++ = (char)(n < 10 ? '0' + n : 'A' + n - 10);
    }
    *d = 0;
    return d;
}

static int diag_on;

/* Compteurs de diagnostic, affichés en direct pendant la lecture. */
static void diag_draw(void)
{
    char b[80], *p;
    int i;
    if (!diag_on)
        return;
    p = put_str(b, "lect ");    p = put_uint(p, da_diag.reads, 1);
    p = put_str(p, "  sans-sync "); p = put_uint(p, da_diag.nosync, 1);
    p = put_str(p, "  sync/lect "); p = put_uint(p, da_diag.last_sync, 1);
    p = put_str(p, "  IDAM ");  p = put_uint(p, da_diag.idam, 1);
    p = put_str(p, "  CRC- ");  p = put_uint(p, da_diag.crc_err, 1);
    p = put_str(p, "  etat ");  put_uint(p, da_diag.status_ok, 1);
    ui_clear_row(16);
    ui_center(16, b);
    p = put_str(b, "ecr ");     p = put_uint(p, da_diag.writes, 1);
    p = put_str(p, "  cmd-ok ");  p = put_uint(p, da_diag.cmd_ok, 1);
    p = put_str(p, "  cmd-reessai "); p = put_uint(p, da_diag.cmd_retry, 1);
    p = put_str(p, "  blocs "); p = put_uint(p, da_diag.lba_ok, 1);
    p = put_str(p, "  LBA ");   put_hex(p, da_diag.last_lba, 8);
    ui_clear_row(17);
    ui_center(17, b);
    p = b;
    for (i = 0; i < 6; i++) {
        p = put_hex(p, da_diag.last_w[i], 4);
        p = put_str(p, " ");
    }
    p = put_str(p, "  ");
    put_str(p, dast.fw_ver);
    ui_clear_row(18);
    ui_center(18, b);
}

static void diag_static(void)
{
    ui_row_colors(16, C_BG, C_DIM);
    ui_row_colors(17, C_BG, C_DIM);
    ui_row_colors(18, C_BG, C_DIM);
    diag_on = 1;
    diag_draw();
    diag_on = 0;
    show();
}

static int scan(void)
{
    char buf[80], *p;
    int r;

    for (;;) {
        draw_frame();
        subtitle("Lecture de la clé USB...");
        footer("Patientez...");
        message("Lecture du catalogue de la clé USB", "(mode Direct Access)",
                C_TEXT);
        ui_row_colors(16, C_BG, C_DIM);
        ui_row_colors(17, C_BG, C_DIM);
        ui_row_colors(18, C_BG, C_DIM);
        show();
        diag_on = 1;
        diag_draw();
        r = da_enter(&dast);
        if (r != DA_OK) {
            hw_drive_off();
            diag_on = 0;
            footer("RETURN / FEU : réessayer");
            message("Le Gotek ne répond pas en mode Direct Access.",
                    "Vérifiez FlashFloppy v3+ et  max-cyl = 255  dans FF.CFG",
                    C_ERR);
            diag_static();
            wait_fire();
            continue;
        }
        own_slot = dast.current_index;
        n_entries = 0;
        mem_set(slot_seen, 0, sizeof(slot_seen));
        r = fat_scan_root(add_entry);
        hw_drive_off(); /* la tête reste au cylindre 255 */
        diag_on = 0;
        if (r != FAT_OK) {
            footer("RETURN / FEU : réessayer");
            message(r == FAT_ERR_NOFS
                    ? "Clé USB non reconnue (FAT12/16/32 requis, pas exFAT)."
                    : "Erreur de lecture de la clé USB.", 0, C_ERR);
            diag_static();
            wait_fire();
            continue;
        }
        sort_entries();
        p = put_uint(buf, n_entries, 1);
        p = put_str(p, n_entries > 1 ? " disquettes trouvées" : " disquette trouvée");
        p = put_str(p, "     Gotek ");
        put_str(p, dast.fw_ver);
        subtitle(buf);
        if (n_entries == 0) {
            footer("R / RETURN / FEU : relire la clé");
            message("Aucune image DSKAnnnn_*.adf trouvée sur la clé.",
                    "(DSKA0000 = Kickstart et le menu sont exclus)", C_ERR);
            wait_fire();
            continue;
        }
        return 0;
    }
}

/* ------------------------------------------------------------------ */
/* Lancement                                                             */

static void launch(const struct entry *e)
{
    int r;
    footer("Chargement...");
    message("Chargement de :", e->name, C_HEAD_FG);
    r = da_enter(&dast);
    if (r == DA_OK)
        r = da_select_image(e->slot);
    if (r != DA_OK) {
        hw_drive_off();
        footer("RETURN / FEU : retour au menu");
        message("Le Gotek a refusé le changement de disquette.",
                e->name, C_ERR);
        wait_fire();
        return;
    }
    da_leave();           /* tête au cylindre 0 : FlashFloppy monte l'image */
    hw_delay_ms(1500);
    footer("Si rien ne se passe : CTRL + Amiga + Amiga");
    message("Redémarrage...", e->name, C_HEAD_FG);
    hw_delay_ms(200);
    hw_reboot();
}

/* ------------------------------------------------------------------ */

int main(void)
{
    da_hook = diag_draw;
    hw_takeover();
    ui_init(bitplane);
    draw_frame();
    show();

    scan();
    sel = top = 0;

    for (;;) {
        int k;
        footer("\x80\x81 choisir   \xAB\xBB page   RETURN / FEU lancer   R relire la clé");
        draw_list();
        update_selection(1);
        for (;;) {
            unsigned old = sel;
            hw_wait_frame();
            k = hw_input();
            if (k == KEY_UP && sel > 0)
                sel--;
            else if (k == KEY_DOWN && sel + 1 < n_entries)
                sel++;
            else if (k == KEY_LEFT)
                sel = (sel > LIST_ROWS) ? sel - LIST_ROWS : 0;
            else if (k == KEY_RIGHT)
                sel = (sel + LIST_ROWS < n_entries) ? sel + LIST_ROWS
                                                    : n_entries - 1;
            else if (k == KEY_HOME)
                sel = 0;
            else if (k == KEY_END)
                sel = n_entries - 1;
            else if (k == KEY_FIRE) {
                launch(&entries[order[sel]]);
                draw_frame();
                break;
            } else if (k == KEY_RESCAN) {
                scan();
                sel = top = 0;
                break;
            }
            if (sel != old)
                update_selection(0);
        }
        if (k == KEY_FIRE) { /* retour après échec : rafraîchir le titre */
            char buf[80], *p;
            p = put_uint(buf, n_entries, 1);
            p = put_str(p, " disquettes trouvées     Gotek ");
            put_str(p, dast.fw_ver);
            subtitle(buf);
        }
    }
    return 0;
}
