/*
 * ui.c : rendu texte dans le plan de bits et construction des listes Copper.
 */
#include "ui.h"

extern const uint8_t font8x8[];

#define COP_WORDS 256
#define DISP_TOP  0x2C            /* première ligne affichée */

static uint8_t *bpl;
static uint16_t cop[2][COP_WORDS];
static int      cop_next;
static uint16_t row_c0[UI_ROWS], row_c1[UI_ROWS];

#define BORDER_COLOR 0x113

void ui_init(uint8_t *bitplane)
{
    int r;
    bpl = bitplane;
    mem_set(bpl, 0, UI_BPL_BYTES);
    for (r = 0; r < UI_ROWS; r++) {
        row_c0[r] = BORDER_COLOR;
        row_c1[r] = 0xBBC;
    }
}

const uint8_t *ui_bitplane(void)
{
    return bpl;
}

void ui_clear_row(int row)
{
    if (row >= 0 && row < UI_ROWS)
        mem_set(bpl + row * 8 * UI_COLS, 0, 8 * UI_COLS);
}

void ui_clear_rows(int r0, int r1)
{
    for (; r0 <= r1; r0++)
        ui_clear_row(r0);
}

void ui_putc(int col, int row, unsigned char c)
{
    const uint8_t *g;
    uint8_t *d;
    int i;
    if (col < 0 || col >= UI_COLS || row < 0 || row >= UI_ROWS)
        return;
    if (c < 0x20)
        c = ' ';
    g = font8x8 + (c - 0x20) * 8;
    d = bpl + row * 8 * UI_COLS + col;
    for (i = 0; i < 8; i++)
        d[i * UI_COLS] = g[i];
}

int ui_print_n(int col, int row, const char *s, int maxlen)
{
    while (*s && maxlen-- > 0 && col < UI_COLS)
        ui_putc(col++, row, (unsigned char)*s++);
    return col;
}

int ui_print(int col, int row, const char *s)
{
    return ui_print_n(col, row, s, UI_COLS);
}

void ui_center(int row, const char *s)
{
    int n = str_len(s);
    if (n > UI_COLS)
        n = UI_COLS;
    ui_print_n((UI_COLS - n) / 2, row, s, n);
}

void ui_hline(int row, int ypix)
{
    mem_set(bpl + (row * 8 + ypix) * UI_COLS, 0xFF, UI_COLS);
}

void ui_row_colors(int row, uint16_t c0, uint16_t c1)
{
    if (row >= 0 && row < UI_ROWS) {
        row_c0[row] = c0;
        row_c1[row] = c1;
    }
}

const uint16_t *ui_build_copper(void)
{
    uint16_t *w = cop[cop_next];
    uint32_t a = (uint32_t)(uintptr_t)bpl;
    uint16_t p0, p1;
    int r;

#define MOVE(reg, val) do { *w++ = (uint16_t)(reg); *w++ = (uint16_t)(val); } while (0)
#define WAIT(line)     do { *w++ = (uint16_t)(((line) << 8) | 0x07); *w++ = 0xFFFE; } while (0)

    MOVE(0x100, 0x9200);          /* BPLCON0 : hires, 1 plan, couleur */
    MOVE(0x102, 0x0000);          /* BPLCON1 */
    MOVE(0x104, 0x0000);          /* BPLCON2 */
    MOVE(0x108, 0x0000);          /* BPL1MOD */
    MOVE(0x10A, 0x0000);          /* BPL2MOD */
    MOVE(0x08E, 0x2C81);          /* DIWSTRT */
    MOVE(0x090, 0xF4C1);          /* DIWSTOP : 200 lignes (PAL et NTSC) */
    MOVE(0x092, 0x003C);          /* DDFSTRT hires */
    MOVE(0x094, 0x00D4);          /* DDFSTOP */
    MOVE(0x0E0, a >> 16);         /* BPL1PTH */
    MOVE(0x0E2, a & 0xFFFF);      /* BPL1PTL */
    MOVE(0x180, BORDER_COLOR);
    MOVE(0x182, row_c1[0]);
    p0 = BORDER_COLOR;
    p1 = row_c1[0];
    for (r = 0; r < UI_ROWS; r++) {
        if (row_c0[r] != p0 || row_c1[r] != p1) {
            WAIT(DISP_TOP + r * 8);
            if (row_c0[r] != p0)
                MOVE(0x180, row_c0[r]);
            if (row_c1[r] != p1)
                MOVE(0x182, row_c1[r]);
            p0 = row_c0[r];
            p1 = row_c1[r];
        }
    }
    if (p0 != BORDER_COLOR) {
        WAIT(DISP_TOP + UI_ROWS * 8);
        MOVE(0x180, BORDER_COLOR);
    }
    *w++ = 0xFFFF;
    *w++ = 0xFFFE;
#undef MOVE
#undef WAIT

    w = cop[cop_next];
    cop_next ^= 1;
    return w;
}
