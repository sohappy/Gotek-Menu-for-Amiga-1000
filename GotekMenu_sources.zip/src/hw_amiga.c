/*
 * hw_amiga.c : accès matériel direct (OCS, 68000) — aucun appel système.
 * Le système est coupé (interruptions et DMA) une fois le programme chargé :
 * on redémarre la machine pour lancer le jeu choisi, donc pas de retour à l'OS.
 */
#include "hw.h"

#define CUSTOM      0xDFF000UL
#define R16(o)      (*(volatile uint16_t *)(CUSTOM + (o)))
#define R32(o)      (*(volatile uint32_t *)(CUSTOM + (o)))

#define VPOSR       0x004
#define JOY1DAT     0x00C
#define INTREQR     0x01E
#define DSKPTH      0x020
#define DSKLEN      0x024
#define DSKSYNC     0x07E
#define COP1LC      0x080
#define COPJMP1     0x088
#define DMACON      0x096
#define INTENA      0x09A
#define INTREQ      0x09C
#define ADKCON      0x09E
#define SPR0POS     0x140
#define COLOR00     0x180

#define CIAA_PRA    (*(volatile uint8_t *)0xBFE001)
#define CIAA_SDR    (*(volatile uint8_t *)0xBFEC01)
#define CIAA_ICR    (*(volatile uint8_t *)0xBFED01)
#define CIAA_CRA    (*(volatile uint8_t *)0xBFEE01)
#define CIAB_PRB    (*(volatile uint8_t *)0xBFD100)

/* CIAB PRB : bit7 /MTR, 6..3 /SEL3../SEL0, 2 /SIDE, 1 DIR, 0 /STEP */
#define PRB_MTR     0x80
#define PRB_SEL0    0x08
#define PRB_SIDE    0x04
#define PRB_DIR     0x02
#define PRB_STEP    0x01
/* CIAA PRA : bit7 /FIRE port 2, bit5 /RDY, bit4 /TRK0, bit2 /CHNG */
#define PRA_FIRE1   0x80
#define PRA_RDY     0x20
#define PRA_TRK0    0x10

static uint8_t prb = 0xFF;
static int     display_on;

/* ------------------------------------------------------------------ */
/* Temporisation par le faisceau vidéo (1 ligne ~ 64 µs)                */

static uint16_t vline(void)
{
    return (uint16_t)((R32(VPOSR) >> 8) & 0x1FF);
}

static void delay_lines(unsigned n)
{
    uint16_t last = vline();
    while (n) {
        uint16_t cur = vline();
        if (cur != last) {
            last = cur;
            n--;
        }
    }
}

void hw_delay_ms(unsigned ms)
{
    delay_lines(ms << 4);
}

void hw_wait_frame(void)
{
    while (vline() != 250)
        ;
    while (vline() == 250)
        ;
}

/* ------------------------------------------------------------------ */
/* Système                                                               */

void hw_takeover(void)
{
    int i;
    R16(INTENA) = 0x7FFF;         /* plus d'interruptions : plus d'OS */
    R16(INTREQ) = 0x7FFF;
    R16(INTREQ) = 0x7FFF;
    hw_wait_frame();
    R16(DMACON) = 0x7FFF;         /* tout DMA coupé */
    R16(DSKLEN) = 0x4000;
    for (i = 0; i < 8; i++) {     /* désarme les sprites */
        R16(SPR0POS + i * 8 + 2) = 0;
        R16(SPR0POS + i * 8 + 4) = 0;
        R16(SPR0POS + i * 8 + 6) = 0;
    }
    R16(COLOR00) = 0x113;
    CIAA_CRA &= (uint8_t)~0x40;   /* port série clavier en entrée */
    (void)CIAA_ICR;
    prb = 0xFF;
    CIAB_PRB = prb;
}

void hw_set_display(const uint8_t *bitplane, const uint16_t *copper)
{
    (void)bitplane;               /* pointeur de plan posé par le Copper */
    R32(COP1LC) = (uint32_t)copper;
    if (!display_on) {
        R16(COPJMP1) = 0;
        R16(DMACON) = 0x8380;     /* SET | DMAEN | BPLEN | COPEN */
        display_on = 1;
    }
}

/* hw_reboot() est en assembleur (crt0.S). */

/* ------------------------------------------------------------------ */
/* Lecteur DF0:                                                          */

static void prb_w(uint8_t v)
{
    prb = v;
    CIAB_PRB = v;
}

void hw_drive_on(void)
{
    unsigned t = 0;
    prb_w(0xFF);
    prb_w((uint8_t)(0xFF & ~PRB_MTR));               /* moteur ON ... */
    prb_w((uint8_t)(0xFF & ~(PRB_MTR | PRB_SEL0)));  /* ... verrouillé par SEL0 */
    while ((CIAA_PRA & PRA_RDY) && t++ < 500 * 16)   /* attente RDY (max 0,5 s) */
        delay_lines(1);
}

void hw_drive_off(void)
{
    prb_w(0xFF);                                     /* désélection */
    prb_w((uint8_t)(0xFF & ~PRB_SEL0));              /* MTR=1 verrouillé : moteur OFF */
    prb_w(0xFF);
}

int hw_track0(void)
{
    return !(CIAA_PRA & PRA_TRK0);
}

void hw_step(int inward)
{
    uint8_t v = prb | PRB_STEP;
    if (inward)
        v &= (uint8_t)~PRB_DIR;     /* DIR=0 : vers le centre */
    else
        v |= PRB_DIR;               /* DIR=1 : vers la piste 0 */
    prb_w(v);
    delay_lines(1);
    prb_w((uint8_t)(v & ~PRB_STEP));
    delay_lines(1);
    prb_w(v);
    delay_lines(48);                /* ~3 ms entre deux pas */
}

void hw_settle(void)
{
    hw_delay_ms(20);
}

static int wait_dskblk(unsigned ms)
{
    unsigned n = ms << 4;
    uint16_t last = vline();
    while (!(R16(INTREQR) & 0x0002)) {
        uint16_t cur = vline();
        if (cur != last) {
            last = cur;
            if (!n--)
                return -1;
        }
    }
    return 0;
}

int hw_read_raw(uint16_t *buf, unsigned nwords)
{
    int r;
    if (nwords == 0 || nwords > 0x3FFF)
        return -1;
    R16(DSKLEN) = 0x4000;
    R16(ADKCON) = 0x7F00;
    R16(ADKCON) = 0x9500;           /* SET | MFMPREC | WORDSYNC | FAST */
    R16(DSKSYNC) = 0x4489;
    R32(DSKPTH) = (uint32_t)buf;
    R16(DMACON) = 0x8210;           /* SET | DMAEN | DSKEN */
    R16(INTREQ) = 0x0002;
    R16(DSKLEN) = (uint16_t)(0x8000 | nwords);
    R16(DSKLEN) = (uint16_t)(0x8000 | nwords);
    r = wait_dskblk(1200);
    R16(DSKLEN) = 0x4000;
    R16(INTREQ) = 0x0002;
    return r;
}

int hw_write_raw(const uint16_t *buf, unsigned nwords)
{
    int r;
    if (nwords == 0 || nwords > 0x3FFF)
        return -1;
    R16(DSKLEN) = 0x4000;
    R16(ADKCON) = 0x7F00;
    R16(ADKCON) = 0x9100;           /* SET | MFMPREC | FAST, précomp. 0 */
    R32(DSKPTH) = (uint32_t)buf;
    R16(DMACON) = 0x8210;
    R16(INTREQ) = 0x0002;
    R16(DSKLEN) = (uint16_t)(0xC000 | nwords);
    R16(DSKLEN) = (uint16_t)(0xC000 | nwords);
    r = wait_dskblk(500);
    delay_lines(2);                 /* laisse sortir le dernier mot */
    R16(DSKLEN) = 0x4000;
    R16(INTREQ) = 0x0002;
    delay_lines(16);                /* FlashFloppy traite la commande */
    return r;
}

/* ------------------------------------------------------------------ */
/* Clavier (CIA-A, port série) et joystick port 2                        */

static int kb_held;          /* action maintenue au clavier */
static int rep_dir, rep_timer, fire_prev;

static int key_action(uint8_t code)
{
    switch (code) {
    case 0x4C: return KEY_UP;
    case 0x4D: return KEY_DOWN;
    case 0x4F: return KEY_LEFT;
    case 0x4E: return KEY_RIGHT;
    case 0x44: /* RETURN */
    case 0x43: /* ENTER */
    case 0x40: return KEY_FIRE;  /* ESPACE */
    case 0x13: return KEY_RESCAN; /* R */
    case 0x3D: return KEY_HOME;  /* pavé 7 */
    case 0x1D: return KEY_END;   /* pavé 1 */
    case 0x3F: return KEY_LEFT;  /* pavé 9 : page préc. */
    case 0x1F: return KEY_RIGHT; /* pavé 3 : page suiv. */
    case 0x3E: return KEY_UP;    /* pavé 8 */
    case 0x1E: return KEY_DOWN;  /* pavé 2 */
    }
    return KEY_NONE;
}

int hw_input(void)
{
    int act = KEY_NONE, dir = KEY_NONE, fire;
    uint16_t j;

    if (CIAA_ICR & 0x08) {
        uint8_t c = CIAA_SDR;
        CIAA_CRA |= 0x40;            /* poignée de main : SP en sortie */
        delay_lines(2);              /* >= 85 µs */
        CIAA_CRA &= (uint8_t)~0x40;
        c = (uint8_t)~c;
        c = (uint8_t)((c >> 1) | (c << 7));
        if (c & 0x80) {              /* relâchement */
            if (key_action(c & 0x7F) == kb_held)
                kb_held = KEY_NONE;
        } else {
            int a = key_action(c);
            if (a == KEY_FIRE || a == KEY_RESCAN || a == KEY_HOME
                || a == KEY_END)
                act = a;
            else if (a != KEY_NONE) {
                kb_held = a;
                rep_dir = KEY_NONE;  /* force une action immédiate */
            }
        }
    }

    j = R16(JOY1DAT);
    if (((j >> 9) ^ (j >> 8)) & 1)
        dir = KEY_UP;
    else if (((j >> 1) ^ j) & 1)
        dir = KEY_DOWN;
    else if ((j >> 9) & 1)
        dir = KEY_LEFT;
    else if ((j >> 1) & 1)
        dir = KEY_RIGHT;
    if (dir == KEY_NONE)
        dir = kb_held;

    fire = !(CIAA_PRA & PRA_FIRE1);
    if (fire && !fire_prev && act == KEY_NONE)
        act = KEY_FIRE;
    fire_prev = fire;

    if (dir != rep_dir) {
        rep_dir = dir;
        rep_timer = 18;
        if (dir != KEY_NONE && act == KEY_NONE)
            act = dir;
    } else if (dir != KEY_NONE && --rep_timer <= 0) {
        rep_timer = 4;
        if (act == KEY_NONE)
            act = dir;
    }
    return act;
}
