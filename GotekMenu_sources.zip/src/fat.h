/*
 * fat.h : lecture du répertoire racine d'une clé FAT12/16/32 via Direct Access.
 */
#ifndef FAT_H
#define FAT_H

#include "common.h"

#define FAT_OK        0
#define FAT_ERR_IO   -1     /* lecture DA impossible */
#define FAT_ERR_NOFS -2     /* pas de volume FAT reconnu */

#define FAT_ATTR_DIR  0x10

/* Appelée pour chaque fichier/dossier du répertoire racine.
 * name : nom long (ou 8.3) converti en Latin-1, terminé par 0. */
typedef void (*fat_cb)(const char *name, uint32_t size, uint8_t attr);

int fat_scan_root(fat_cb cb);

#endif
