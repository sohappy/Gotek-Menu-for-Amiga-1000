/*
 * GotekMenu - menu de lancement pour Amiga 1000 + Gotek FlashFloppy (mode indexé)
 * common.h : types et utilitaires partagés (code portable Amiga / PC de test)
 */
#ifndef COMMON_H
#define COMMON_H

#include <stdint.h>
#include <stddef.h>

/* Lecture little-endian depuis un tampon d'octets (indépendant du CPU). */
static inline uint16_t le16(const uint8_t *p)
{
    return (uint16_t)(p[0] | (p[1] << 8));
}
static inline uint32_t le32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8)
        | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

void *mem_set(void *d, int c, size_t n);
void *mem_cpy(void *d, const void *s, size_t n);
int str_len(const char *s);

/* Préfixe des images en mode indexé (indexed-prefix de FF.CFG). */
#define INDEX_PREFIX "DSKA"

#endif
