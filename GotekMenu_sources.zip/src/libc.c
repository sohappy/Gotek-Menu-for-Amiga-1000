/*
 * libc.c : fonctions minimales (pas de bibliothèque C sur la cible).
 */
#include "common.h"

void *mem_set(void *d, int c, size_t n)
{
    uint8_t *p = d;
    while (n--)
        *p++ = (uint8_t)c;
    return d;
}

void *mem_cpy(void *d, const void *s, size_t n)
{
    uint8_t *p = d;
    const uint8_t *q = s;
    while (n--)
        *p++ = *q++;
    return d;
}

int str_len(const char *s)
{
    int n = 0;
    while (s[n])
        n++;
    return n;
}

#ifdef __mc68000__
/* GCC peut générer des appels implicites à memset/memcpy. */
void *memset(void *d, int c, size_t n) { return mem_set(d, c, n); }
void *memcpy(void *d, const void *s, size_t n) { return mem_cpy(d, s, n); }

/* Arithmétique 32 bits pour 68000 (la libgcc du système vise le 68020). */
unsigned long __mulsi3(unsigned long a, unsigned long b)
{
    unsigned long r = 0;
    while (b) {
        if (b & 1)
            r += a;
        a <<= 1;
        b >>= 1;
    }
    return r;
}

static unsigned long udivmod(unsigned long n, unsigned long d, int mod)
{
    unsigned long q = 0, bit = 1;
    if (d == 0)
        return 0;
    while (d < n && !(d & 0x80000000UL)) {
        d <<= 1;
        bit <<= 1;
    }
    while (bit) {
        if (n >= d) {
            n -= d;
            q |= bit;
        }
        d >>= 1;
        bit >>= 1;
    }
    return mod ? n : q;
}

unsigned long __udivsi3(unsigned long n, unsigned long d) { return udivmod(n, d, 0); }
unsigned long __umodsi3(unsigned long n, unsigned long d) { return udivmod(n, d, 1); }
long __divsi3(long n, long d)
{
    int neg = (n < 0) ^ (d < 0);
    unsigned long q = udivmod(n < 0 ? -(unsigned long)n : (unsigned long)n,
                              d < 0 ? -(unsigned long)d : (unsigned long)d, 0);
    return neg ? -(long)q : (long)q;
}
long __modsi3(long n, long d)
{
    unsigned long r = udivmod(n < 0 ? -(unsigned long)n : (unsigned long)n,
                              d < 0 ? -(unsigned long)d : (unsigned long)d, 1);
    return n < 0 ? -(long)r : (long)r;
}
#endif
