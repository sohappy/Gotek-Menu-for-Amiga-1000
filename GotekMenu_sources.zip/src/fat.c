/*
 * fat.c : parcours du répertoire racine (FAT12/FAT16/FAT32, MBR ou
 * "superfloppy"), avec noms longs (VFAT). FlashFloppy ne gère pas exFAT.
 * Les secteurs sont lus 8 par 8 via le protocole Direct Access.
 */
#include "fat.h"
#include "da.h"

#define BLK_SECS  DA_NR_DATA_SEC
#define BLK_BYTES (BLK_SECS * 512)

static uint8_t  dirblk[BLK_BYTES];
static uint32_t dir_tag;
static int      dir_ok;
static uint8_t  fatblk[BLK_BYTES];
static uint32_t fat_tag;
static int      fat_ok;

static char     lfn[256];
static char     name[256];

static const uint8_t *get_sec(uint32_t lba, uint8_t *blk, uint32_t *tag,
                              int *ok)
{
    uint32_t base = lba & ~(uint32_t)(BLK_SECS - 1);
    if (!*ok || *tag != base) {
        *ok = 0;
        if (da_read_lba(base, blk) != DA_OK)
            return NULL;
        *tag = base;
        *ok = 1;
    }
    return blk + ((lba - base) << 9);
}

#define DIRSEC(l) get_sec((l), dirblk, &dir_tag, &dir_ok)
#define FATSEC(l) get_sec((l), fatblk, &fat_tag, &fat_ok)

static int is_vbr(const uint8_t *s)
{
    uint8_t spc = s[13];
    if (s[0] != 0xEB && s[0] != 0xE9 && s[0] != 0xE8)
        return 0;
    if (le16(s + 11) != 512)
        return 0;
    if (spc == 0 || (spc & (spc - 1)))
        return 0;
    if (s[16] < 1 || s[16] > 2)
        return 0;
    return le16(s + 14) != 0;
}

static unsigned log2u(unsigned v)
{
    unsigned n = 0;
    while (v > 1) {
        v >>= 1;
        n++;
    }
    return n;
}

/* Paramètres du volume */
static int      fat_type;      /* 12, 16, 32 */
static uint32_t fat_start, root_start, root_secs, data_start, root_clus;
static unsigned spc_shift, spc;

static uint32_t next_cluster(uint32_t cl)
{
    const uint8_t *s;
    uint32_t off;
    if (fat_type == 32) {
        off = cl << 2;
        s = FATSEC(fat_start + (off >> 9));
        if (!s)
            return 0xFFFFFFFF;
        return le32(s + (off & 511)) & 0x0FFFFFFF;
    } else { /* FAT16 (la racine FAT12/16 n'est jamais chaînée) */
        off = cl << 1;
        s = FATSEC(fat_start + (off >> 9));
        if (!s)
            return 0xFFFFFFFF;
        return le16(s + (off & 511));
    }
}

/* État noms longs */
static int     lfn_expect;    /* prochain ordinal attendu (0 = complet) */
static uint8_t lfn_chk;
static int     lfn_valid;

static const uint8_t lfn_off[13] __attribute__((aligned(4))) = { 1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24,
                                     28, 30 };

/* 0 = continuer, 1 = fin du répertoire */
static int do_sector(const uint8_t *s, fat_cb cb)
{
    unsigned e;
    for (e = 0; e < 16; e++, s += 32) {
        uint8_t attr = s[11];
        if (s[0] == 0x00)
            return 1;
        if (s[0] == 0xE5) {
            lfn_valid = 0;
            continue;
        }
        if ((attr & 0x3F) == 0x0F) {
            unsigned ord = s[0] & 0x1F, k, pos;
            if (s[0] & 0x40) {
                lfn_valid = (ord >= 1 && ord <= 19);
                lfn_expect = (int)ord;
                lfn_chk = s[13];
                mem_set(lfn, 0, sizeof(lfn));
            }
            if (!lfn_valid || (int)ord != lfn_expect || s[13] != lfn_chk) {
                lfn_valid = 0;
                continue;
            }
            pos = (ord - 1) * 13;
            for (k = 0; k < 13 && pos + k < 255; k++) {
                uint16_t c = le16(s + lfn_off[k]);
                if (c == 0x0000 || c == 0xFFFF)
                    c = 0;
                else if (c > 0xFF)
                    c = '?';
                lfn[pos + k] = (char)c;
            }
            lfn_expect--;
            continue;
        }
        if (attr & 0x08) { /* étiquette de volume */
            lfn_valid = 0;
            continue;
        }
        {
            uint8_t sum = 0;
            unsigned i, n = 0;
            for (i = 0; i < 11; i++)
                sum = (uint8_t)(((sum & 1) << 7) + (sum >> 1) + s[i]);
            if (lfn_valid && lfn_expect == 0 && sum == lfn_chk && lfn[0]) {
                for (i = 0; i < 255 && lfn[i]; i++)
                    name[i] = lfn[i];
                n = i;
            } else {
                for (i = 0; i < 8 && s[i] != ' '; i++)
                    name[n++] = (char)((i == 0 && s[0] == 0x05) ? 0xE5 : s[i]);
                if (s[8] != ' ') {
                    name[n++] = '.';
                    for (i = 8; i < 11 && s[i] != ' '; i++)
                        name[n++] = (char)s[i];
                }
            }
            name[n] = 0;
            lfn_valid = 0;
            cb(name, le32(s + 28), attr);
        }
    }
    return 0;
}

int fat_scan_root(fat_cb cb)
{
    const uint8_t *s;
    uint8_t ptab[64] __attribute__((aligned(4)));
    uint32_t vol = 0, totsec, fatsz, rsvd, nfats, rootents, clusters;
    unsigned i;

    dir_ok = fat_ok = 0;
    lfn_valid = 0;

    s = DIRSEC(0);
    if (!s)
        return FAT_ERR_IO;
    if (s[510] != 0x55 || s[511] != 0xAA)
        return FAT_ERR_NOFS;
    if (!is_vbr(s)) {
        int found = 0;
        mem_cpy(ptab, s + 446, 64);
        for (i = 0; i < 4 && !found; i++) {
            const uint8_t *pe = ptab + 16 * i;
            uint32_t start = le32(pe + 8);
            if (pe[4] == 0 || start == 0)
                continue;
            s = DIRSEC(start);
            if (!s)
                return FAT_ERR_IO;
            if (is_vbr(s)) {
                vol = start;
                found = 1;
            }
        }
        if (!found)
            return FAT_ERR_NOFS;
    }
    /* s pointe sur le secteur de boot du volume */
    spc = s[13];
    spc_shift = log2u(spc);
    rsvd = le16(s + 14);
    nfats = s[16];
    rootents = le16(s + 17);
    totsec = le16(s + 19) ? le16(s + 19) : le32(s + 32);
    fatsz = le16(s + 22) ? le16(s + 22) : le32(s + 36);
    root_clus = le32(s + 44);

    root_secs = (rootents * 32 + 511) >> 9;
    fat_start = vol + rsvd;
    root_start = fat_start + fatsz;
    if (nfats == 2)
        root_start += fatsz;
    data_start = root_start + root_secs;
    clusters = (totsec - (data_start - vol)) >> spc_shift;
    fat_type = (clusters < 4085) ? 12 : (clusters < 65525) ? 16 : 32;
    if (fat_type == 32 && (root_secs != 0 || le16(s + 22) != 0))
        return FAT_ERR_NOFS;

    if (fat_type != 32) {
        for (i = 0; i < root_secs; i++) {
            s = DIRSEC(root_start + i);
            if (!s)
                return FAT_ERR_IO;
            if (do_sector(s, cb))
                break;
        }
    } else {
        uint32_t cl = root_clus;
        unsigned guard = 0;
        while (cl >= 2 && cl < 0x0FFFFFF8 && guard++ < 4096) {
            for (i = 0; i < spc; i++) {
                s = DIRSEC(data_start + ((cl - 2) << spc_shift) + i);
                if (!s)
                    return FAT_ERR_IO;
                if (do_sector(s, cb))
                    return FAT_OK;
            }
            cl = next_cluster(cl);
            if (cl == 0xFFFFFFFF)
                return FAT_ERR_IO;
        }
    }
    return FAT_OK;
}
