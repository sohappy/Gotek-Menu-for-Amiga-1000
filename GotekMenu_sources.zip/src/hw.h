/*
 * hw.h : couche matérielle. Implémentée par hw_amiga.c (vrai Amiga) et
 * par test/sim_hw.c (simulation FlashFloppy sur PC).
 */
#ifndef HW_H
#define HW_H

#include "common.h"

/* --- Système --- */
void hw_takeover(void);            /* coupe l'OS, installe notre affichage */
void hw_set_display(const uint8_t *bitplane, const uint16_t *copper);
void hw_wait_frame(void);          /* attend la prochaine trame vidéo */
void hw_delay_ms(unsigned ms);
void hw_reboot(void);              /* reset "magique" (Kickstart conservé) */

/* --- Lecteur DF0: (le Gotek) --- */
void hw_drive_on(void);
void hw_drive_off(void);
int  hw_track0(void);              /* 1 si la tête est au cylindre 0 */
void hw_step(int inward);          /* un pas (inward=1 : vers cyl. hauts) */
void hw_settle(void);              /* délai de stabilisation après seek */
/* Lecture brute MFM (synchro 0x4489), nwords mots de 16 bits. 0 = OK */
int  hw_read_raw(uint16_t *buf, unsigned nwords);
/* Écriture brute MFM immédiate (pas d'attente d'index). 0 = OK */
int  hw_write_raw(const uint16_t *buf, unsigned nwords);

/* --- Entrées --- */
enum {
    KEY_NONE = 0, KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT,
    KEY_FIRE, KEY_HOME, KEY_END, KEY_RESCAN
};
/* Renvoie une action (clavier ou joystick port 2, avec répétition). */
int hw_input(void);

#endif
