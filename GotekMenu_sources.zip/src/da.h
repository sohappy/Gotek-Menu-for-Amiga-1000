/*
 * da.h : protocole "Direct Access" de FlashFloppy (compatible HxC).
 * Le Gotek présente au cylindre 255 une piste MFM IBM de 9 secteurs de
 * 512 octets : secteur 0 = état / commandes, secteurs 1..8 = secteurs
 * bruts de la clé USB à partir de l'adresse LBA choisie.
 */
#ifndef DA_H
#define DA_H

#include "common.h"

#define DA_CYL           255
#define DA_SEC_SZ        512
#define DA_NR_DATA_SEC   8

#define DA_CMD_NOP           0
#define DA_CMD_SET_LBA       1
#define DA_CMD_SELECT_IMAGE  4

struct da_status {
    char     fw_ver[13];      /* ex. "FF-v3.44" */
    uint32_t lba_base;
    uint8_t  cmd_cnt;
    uint8_t  last_cmd_status; /* 0 = OK */
    uint8_t  nr_sec;
    uint16_t current_index;   /* emplacement monté (DSKAxxxx) */
};

/* Erreurs */
#define DA_OK          0
#define DA_ERR_NOSIG  -1   /* pas de réponse Direct Access */
#define DA_ERR_CMD    -2   /* commande refusée */
#define DA_ERR_READ   -3   /* lecture de secteurs impossible */

int  da_enter(struct da_status *st);       /* positionne la tête sur cyl 255 */
void da_leave(void);                       /* retour cyl 0 (=> remontage image) */
int  da_status(struct da_status *st);
int  da_command(uint8_t cmd, const uint8_t *param, unsigned plen,
                struct da_status *st);
/* Lit 8 secteurs consécutifs de la clé USB à partir de lba. */
int  da_read_lba(uint32_t lba, uint8_t *dst);
int  da_select_image(uint16_t slot);

/* Diagnostic (affiché pendant la lecture de la clé). */
struct da_diag {
    uint16_t reads, nosync, writes;
    uint16_t idam, dam_ok, crc_err, status_ok;
    uint16_t cmd_ok, cmd_retry, lba_ok;
    uint16_t last_sync;          /* nb de 0x4489 dans la dernière lecture */
    uint16_t last_w[6];          /* premiers mots de la dernière lecture */
    uint32_t last_lba;
};
extern struct da_diag da_diag;
extern void (*da_hook)(void);    /* appelé après chaque accès disque */

/* Outils MFM/CRC exposés pour les tests. */
uint16_t crc16_ccitt(const uint8_t *p, unsigned n, uint16_t crc);
uint8_t  mfm_decode(uint16_t w);

#endif
