/*
 * ui.h : écran texte 80x25 (640x200 hires, 1 plan) + barres de couleur
 * gérées par le Copper.
 */
#ifndef UI_H
#define UI_H

#include "common.h"

#define UI_COLS      80
#define UI_ROWS      25
#define UI_BPL_BYTES (UI_COLS * UI_ROWS * 8)   /* 16000 */

void ui_init(uint8_t *bitplane);
void ui_clear_row(int row);
void ui_clear_rows(int r0, int r1);
int  ui_print(int col, int row, const char *s);      /* renvoie col suivante */
int  ui_print_n(int col, int row, const char *s, int maxlen);
void ui_center(int row, const char *s);
void ui_putc(int col, int row, unsigned char c);
void ui_hline(int row, int ypix);
void ui_row_colors(int row, uint16_t c0, uint16_t c1);
const uint16_t *ui_build_copper(void);
const uint8_t *ui_bitplane(void);

#endif
