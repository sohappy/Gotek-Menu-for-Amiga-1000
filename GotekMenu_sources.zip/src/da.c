/*
 * da.c : dialogue "Direct Access" avec FlashFloppy, côté Amiga.
 *
 * Lecture : on lit ~2 tours de la piste DA en MFM brut (synchro 0x4489) et
 * on décode nous-mêmes les secteurs au format IBM (IDAM 0xFE / DAM 0xFB).
 * Écriture : on envoie un "Named Sector" (marque 0x01 + n° de secteur),
 * format accepté par FlashFloppy n'importe où sur la piste, sans index.
 */
#include "da.h"
#include "hw.h"

#define TRACK_WORDS  13000          /* ~2,1 tours de piste DA (6260 mots/tour) */
#define WBUF_WORDS   (40 + 12 + 3 + 2 + 514 + 300)

static uint16_t trackbuf[TRACK_WORDS];
static uint16_t wbuf[WBUF_WORDS];
static uint8_t  secbuf[DA_SEC_SZ + 2];
static uint16_t crc_tab[256];
static uint8_t  dec_tab[256];
static int      tables_ready;
static int      cur_cyl = -1;
static int      known_cnt = -1;      /* dernier cmd_cnt vu (-1 = inconnu) */

struct da_diag da_diag;
void (*da_hook)(void);

static const char da_sig[8] __attribute__((aligned(4))) = { 'H','x','C','F','E','D','A',0 };

/* ------------------------------------------------------------------ */
/* CRC-CCITT et décodage MFM                                            */

static void init_tables(void)
{
    unsigned i, j;
    for (i = 0; i < 256; i++) {
        uint16_t c = (uint16_t)(i << 8);
        for (j = 0; j < 8; j++)
            c = (c & 0x8000) ? (uint16_t)((c << 1) ^ 0x1021) : (uint16_t)(c << 1);
        crc_tab[i] = c;
        /* octet MFM = 4 paires (horloge, donnée) -> 4 bits de données */
        dec_tab[i] = (uint8_t)((((i >> 6) & 1) << 3) | (((i >> 4) & 1) << 2)
                               | (((i >> 2) & 1) << 1) | (i & 1));
    }
    tables_ready = 1;
}

uint16_t crc16_ccitt(const uint8_t *p, unsigned n, uint16_t crc)
{
    if (!tables_ready)
        init_tables();
    while (n--)
        crc = (uint16_t)((crc << 8) ^ crc_tab[(uint8_t)((crc >> 8) ^ *p++)]);
    return crc;
}

uint8_t mfm_decode(uint16_t w)
{
    return (uint8_t)((dec_tab[w >> 8] << 4) | dec_tab[w & 0xff]);
}

/* ------------------------------------------------------------------ */
/* Encodage MFM pour l'écriture                                         */

static unsigned enc_pos;
static unsigned enc_prev;    /* dernier bit de donnée émis */

static void enc_byte(uint8_t b)
{
    uint16_t w = 0;
    int i;
    for (i = 7; i >= 0; i--) {
        unsigned d = (b >> i) & 1;
        unsigned c = !(enc_prev | d);
        w = (uint16_t)((w << 2) | (c << 1) | d);
        enc_prev = d;
    }
    wbuf[enc_pos++] = w;
}

static void enc_raw(uint16_t w)
{
    wbuf[enc_pos++] = w;
    enc_prev = w & 1;
}

/* Écrit le secteur de commande (secteur 0) sur la piste DA. */
static int send_sector0(const uint8_t *data)
{
    uint8_t hdr[5] __attribute__((aligned(4))) = { 0xa1, 0xa1, 0xa1, 0x01, 0x00 };
    uint16_t crc;
    unsigned i;

    crc = crc16_ccitt(hdr, 5, 0xffff);
    crc = crc16_ccitt(data, DA_SEC_SZ, crc);

    enc_pos = 0;
    enc_prev = 0;
    for (i = 0; i < 40; i++) enc_byte(0x4e);
    for (i = 0; i < 12; i++) enc_byte(0x00);
    for (i = 0; i < 3; i++)  enc_raw(0x4489);
    enc_byte(0x01);                 /* "Named Sector" FlashFloppy */
    enc_byte(0x00);                 /* n° de secteur : 0 = commande */
    for (i = 0; i < DA_SEC_SZ; i++) enc_byte(data[i]);
    enc_byte((uint8_t)(crc >> 8));
    enc_byte((uint8_t)crc);
    /* Fin de piste : FlashFloppy exige >128 mots après la donnée. */
    for (i = 0; i < 300; i++) enc_byte(0x4e);

    da_diag.writes++;
    return hw_write_raw(wbuf, enc_pos);
}

/* ------------------------------------------------------------------ */
/* Analyse d'une lecture brute de la piste DA                           */

struct parse {
    /* entrée */
    int       want_data;
    uint32_t  lba;
    uint8_t  *dst;
    /* sortie */
    int       st_valid;
    struct da_status st;
    int       armed;
    uint16_t  got;
};

/* Décode le champ de données (514 mots) vers secbuf ; 1 si CRC correct. */
static int decode_dam(const uint16_t *w)
{
    static const uint8_t dam_hdr[4] __attribute__((aligned(4))) = { 0xa1, 0xa1, 0xa1, 0xfb };
    unsigned i;
    for (i = 0; i < DA_SEC_SZ + 2; i++)
        secbuf[i] = mfm_decode(w[i]);
    return crc16_ccitt(secbuf, DA_SEC_SZ + 2,
                       crc16_ccitt(dam_hdr, 4, 0xffff)) == 0;
}

static void fill_status(struct da_status *st, const uint8_t *s)
{
    unsigned i;
    for (i = 0; i < 12; i++)
        st->fw_ver[i] = (char)s[8 + i];
    st->fw_ver[12] = 0;
    st->lba_base = le32(s + 20);
    st->cmd_cnt = s[24];
    st->last_cmd_status = s[27];
    st->nr_sec = s[33];
    st->current_index = le16(s + 34);
}

static int sig_ok(const uint8_t *s)
{
    unsigned i;
    for (i = 0; i < 8; i++)
        if (s[i] != (uint8_t)da_sig[i])
            return 0;
    return 1;
}

/* Renvoie 1 quand la lecture de données demandée est complète. */
static int parse_track(struct parse *p, unsigned n)
{
    const uint16_t *w = trackbuf;
    unsigned i = 0;
    int cur = -1;

    while (i < n) {
        uint8_t mark;
        if (w[i] != 0x4489) {
            i++;
            continue;
        }
        while (i < n && w[i] == 0x4489)
            i++;
        if (i >= n)
            break;
        mark = mfm_decode(w[i++]);
        if (mark == 0xfe) {
            uint8_t idam[10] __attribute__((aligned(4))) = { 0xa1, 0xa1, 0xa1, 0xfe };
            unsigned k;
            if (i + 6 > n)
                break;
            for (k = 0; k < 6; k++)
                idam[4 + k] = mfm_decode(w[i + k]);
            i += 6;
            cur = (crc16_ccitt(idam, 10, 0xffff) == 0) ? idam[6] : -1;
            if (cur >= 0)
                da_diag.idam++;
            else
                da_diag.crc_err++;
        } else if (mark == 0xfb) {
            int s = cur;
            cur = -1;
            if (s < 0)
                continue;
            if (i + DA_SEC_SZ + 2 > n)
                break;
            if (s == 0) {
                if (decode_dam(&w[i]) && sig_ok(secbuf)) {
                    da_diag.status_ok++;
                    fill_status(&p->st, secbuf);
                    p->st_valid = 1;
                    known_cnt = p->st.cmd_cnt;
                    if (p->want_data) {
                        p->armed = (p->st.lba_base == p->lba);
                        p->got = 0;
                    }
                }
            } else if (p->want_data && p->armed && s <= DA_NR_DATA_SEC) {
                if (!decode_dam(&w[i]))
                    da_diag.crc_err++;
                else {
                    da_diag.dam_ok++;
                    mem_cpy(p->dst + (unsigned)(s - 1) * DA_SEC_SZ, secbuf,
                            DA_SEC_SZ);
                    p->got |= (uint16_t)(1u << s);
                    if (p->got == 0x1fe)
                        return 1;
                }
            }
            i += DA_SEC_SZ + 2;
        } else {
            cur = -1;
        }
    }
    return 0;
}

static int read_parse(struct parse *p)
{
    int r;
    unsigned i, n = 0;
    da_diag.reads++;
    if (hw_read_raw(trackbuf, TRACK_WORDS) != 0) {
        da_diag.nosync++;
        da_diag.last_sync = 0;
        if (da_hook)
            da_hook();
        return 0;
    }
    for (i = 0; i < TRACK_WORDS; i++)
        if (trackbuf[i] == 0x4489)
            n++;
    da_diag.last_sync = (uint16_t)n;
    for (i = 0; i < 6; i++)
        da_diag.last_w[i] = trackbuf[i];
    r = parse_track(p, TRACK_WORDS);
    if (da_hook)
        da_hook();
    return r;
}

/* ------------------------------------------------------------------ */
/* Positionnement de la tête                                            */

static void seek(int cyl)
{
    if (cur_cyl < 0 || cyl == 0) {
        /* Recalibrage : on recule jusqu'au signal TRACK0. */
        int n = 0;
        while (!hw_track0() && n++ < 300)
            hw_step(0);
        cur_cyl = 0;
    }
    while (cur_cyl < cyl) {
        hw_step(1);
        cur_cyl++;
    }
    while (cur_cyl > cyl) {
        hw_step(0);
        cur_cyl--;
    }
    hw_settle();
}

/* ------------------------------------------------------------------ */
/* API                                                                   */

int da_status(struct da_status *st)
{
    struct parse p;
    int tries;
    for (tries = 0; tries < 4; tries++) {
        mem_set(&p, 0, sizeof(p));
        read_parse(&p);
        if (p.st_valid) {
            if (st)
                *st = p.st;
            return DA_OK;
        }
        hw_delay_ms(20);
    }
    return DA_ERR_NOSIG;
}

int da_enter(struct da_status *st)
{
    int tries;
    if (!tables_ready)
        init_tables();
    hw_drive_on();
    known_cnt = -1;
    if (cur_cyl != DA_CYL)
        seek(DA_CYL);
    for (tries = 0; tries < 3; tries++) {
        if (da_status(st) == DA_OK)
            return DA_OK;
        /* Nouvel essai complet : recalibrage puis cylindre 255. */
        cur_cyl = -1;
        seek(DA_CYL);
    }
    return DA_ERR_NOSIG;
}

void da_leave(void)
{
    seek(0);
    hw_drive_off();
    cur_cyl = 0;
}

/* Envoie une commande et attend sa prise en compte (cmd_cnt + 1). */
static int do_command(uint8_t cmd, const uint8_t *param, unsigned plen,
                      struct parse *p)
{
    uint8_t sec[DA_SEC_SZ] __attribute__((aligned(4)));
    unsigned i;
    int attempt, r;

    if (known_cnt < 0 && da_status(NULL) != DA_OK)
        return DA_ERR_NOSIG;

    mem_set(sec, 0, sizeof(sec));
    for (i = 0; i < 8; i++)
        sec[i] = (uint8_t)da_sig[i];
    sec[8] = cmd;
    for (i = 0; i < plen && i < 8; i++)
        sec[9 + i] = param[i];

    for (attempt = 0; attempt < 3; attempt++) {
        uint8_t expect = (uint8_t)(known_cnt + 1);
        send_sector0(sec);
        for (r = 0; r < 3; r++) {
            int done;
            p->st_valid = 0;
            p->armed = 0;
            p->got = 0;
            done = read_parse(p);
            if (p->st_valid && p->st.cmd_cnt == expect) {
                da_diag.cmd_ok++;
                if (p->st.last_cmd_status != 0)
                    return DA_ERR_CMD;
                if (!p->want_data || done)
                    return DA_OK;
                /* commande acceptée, données pas encore complètes */
                for (; r < 4; r++)
                    if (read_parse(p))
                        return DA_OK;
                return DA_ERR_READ;
            }
            if (p->st_valid && p->st.cmd_cnt != (uint8_t)(expect - 1))
                break; /* compteur incohérent : on renvoie */
        }
        da_diag.cmd_retry++;
        if (known_cnt < 0 && da_status(NULL) != DA_OK)
            return DA_ERR_NOSIG;
    }
    return DA_ERR_NOSIG;
}

int da_command(uint8_t cmd, const uint8_t *param, unsigned plen,
               struct da_status *st)
{
    struct parse p;
    int r;
    mem_set(&p, 0, sizeof(p));
    r = do_command(cmd, param, plen, &p);
    if (st && p.st_valid)
        *st = p.st;
    return r;
}

int da_read_lba(uint32_t lba, uint8_t *dst)
{
    struct parse p;
    uint8_t prm[6] __attribute__((aligned(4)));
    int tries, r = DA_ERR_READ;

    prm[0] = (uint8_t)lba;
    prm[1] = (uint8_t)(lba >> 8);
    prm[2] = (uint8_t)(lba >> 16);
    prm[3] = (uint8_t)(lba >> 24);
    prm[4] = 0;
    prm[5] = DA_NR_DATA_SEC;

    for (tries = 0; tries < 3; tries++) {
        mem_set(&p, 0, sizeof(p));
        p.want_data = 1;
        p.lba = lba;
        p.dst = dst;
        da_diag.last_lba = lba;
        r = do_command(DA_CMD_SET_LBA, prm, 6, &p);
        if (r == DA_OK) {
            da_diag.lba_ok++;
            return DA_OK;
        }
    }
    return r;
}

int da_select_image(uint16_t slot)
{
    struct da_status st;
    uint8_t prm[2] __attribute__((aligned(4)));
    int r;
    prm[0] = (uint8_t)slot;
    prm[1] = (uint8_t)(slot >> 8);
    r = da_command(DA_CMD_SELECT_IMAGE, prm, 2, &st);
    if (r != DA_OK)
        return r;
    return (st.current_index == slot) ? DA_OK : DA_ERR_CMD;
}
