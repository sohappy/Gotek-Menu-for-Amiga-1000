#!/usr/bin/env python3
"""Construit DSKA0001_MENU.adf : compile, relie, reloge, bootblock, ADF."""
import os, subprocess, struct, sys
from elftools.elf.elffile import ELFFile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = os.path.join(ROOT, 'build'); os.makedirs(B, exist_ok=True)
CC = 'm68k-linux-gnu-gcc'
CFLAGS = ['-m68000', '-mstrict-align', '-fno-store-merging', '-fno-expensive-optimizations', '-Os', '-ffreestanding', '-fno-builtin', '-nostdlib', '-fno-pic',
          '-fno-tree-loop-distribute-patterns', '-fomit-frame-pointer', '-fno-asynchronous-unwind-tables',
          '-fexec-charset=ISO-8859-1', '-Wall', '-Wextra', '-Wno-unused-parameter', '-Werror']
SRC = ['crt0.S', 'main.c', 'da.c', 'fat.c', 'ui.c', 'hw_amiga.c', 'libc.c', 'font.c']

def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        print(' '.join(cmd)); print(r.stdout, r.stderr); sys.exit(1)
    return r.stdout

objs = []
for s in SRC:
    o = os.path.join(B, s.rsplit('.', 1)[0] + '.o')
    run([CC] + CFLAGS + ['-c', os.path.join(ROOT, 'src', s), '-o', o]); objs.append(o)
elf = os.path.join(B, 'menu.elf')
run(['m68k-linux-gnu-ld', '-T', os.path.join(ROOT, 'tools', 'link.ld'), '-q', '-o', elf] + objs)
binf = os.path.join(B, 'menu.bin')
run(['m68k-linux-gnu-objcopy', '-O', 'binary', '-j', '.text', '-j', '.rodata', '-j', '.data', elf, binf])

with open(elf, 'rb') as f:
    e = ELFFile(f)
    syms = {s.name: s['st_value'] for s in e.get_section_by_name('.symtab').iter_symbols()}
    relocs = []
    for sec in e.iter_sections():
        if not sec.name.startswith('.rela'):
            continue
        tgt = sec.name[5:]
        if tgt not in ('.text', '.rodata', '.data'):
            continue
        base = e.get_section_by_name(tgt)['sh_addr']
        for r in sec.iter_relocations():
            t = r['r_info_type']
            if t == 1:            # R_68K_32 : absolu 32 bits -> à reloger
                relocs.append(r['r_offset'])  # ET_EXEC : adresse virtuelle
            elif t in (4, 5, 6):  # PC-relatif : rien à faire
                pass
            else:
                sys.exit(f'relocation non gérée type {t} dans {tgt}')
relocs.sort()
img = bytearray(open(binf, 'rb').read())
img_end, bss_end = syms['__image_end'], syms['__bss_end']
img += b'\0' * (img_end - len(img))
img += b'\0' * ((-len(img)) % 4)
roff = len(img)
for o in relocs:
    assert o % 2 == 0
    img += struct.pack('>I', o)
struct.pack_into('>II', img, 4, roff, len(relocs))
prog = bytes(img) + b'\0' * ((-len(img)) % 512)
alloc = max(bss_end, len(prog)) + 64
print(f'code+données {img_end} o, relocs {len(relocs)}, fichier {len(prog)} o, mémoire {alloc} o')

# bootblock
bbo = os.path.join(B, 'bootblock.o'); bbb = os.path.join(B, 'bootblock.bin')
run(['m68k-linux-gnu-as', '-m68000', f'--defsym', f'PROG_LEN={len(prog)}', '--defsym', f'ALLOC_LEN={alloc}',
     os.path.join(ROOT, 'boot', 'bootblock.S'), '-o', bbo])
run(['m68k-linux-gnu-objcopy', '-O', 'binary', '-j', '.text', bbo, bbb])
bb = bytearray(open(bbb, 'rb').read()); assert len(bb) <= 1024
bb += b'\0' * (1024 - len(bb))
s = 0
for i in range(0, 1024, 4):
    s += struct.unpack_from('>I', bb, i)[0]
    if s > 0xFFFFFFFF: s = (s & 0xFFFFFFFF) + 1
struct.pack_into('>I', bb, 4, (~s) & 0xFFFFFFFF)
adf = bytes(bb) + prog
assert len(adf) <= 901120
adf += b'\0' * (901120 - len(adf))
out = os.path.join(ROOT, 'DSKA0001_MENU.adf')
open(out, 'wb').write(adf)
print('->', out)
